import com.velaris.anticheat.core.*;
import java.util.*;

/** Mô phỏng người chơi hợp lệ và hack cho từng check chiến đấu. Chạy: xem README. */
public class CombatSim {
    static int passed, failed;
    static void ok(boolean c, String n) { if (c) { passed++; System.out.println("  ✓ " + n); } else { failed++; System.out.println("  ✗ FAIL: " + n); } }

    static final double EYE = 1.62;
    static final long T = 1000;
    static final Random R = new Random(42);

    static CheckSettings cs(Check c) { return CheckSettings.defaults(c); }
    static PlayerData pd() { return new PlayerData(UUID.randomUUID()); }

    static double[] yawPitch(double dx, double dy, double dz) {
        double len = Math.sqrt(dx * dx + dy * dy + dz * dz);
        dx /= len; dy /= len; dz /= len;
        return new double[] {Math.toDegrees(Math.atan2(-dx, dz)), Math.toDegrees(-Math.asin(dy))};
    }
    static double[] unit(double dx, double dy, double dz) {
        double l = Math.sqrt(dx * dx + dy * dy + dz * dz);
        return new double[] {dx / l, dy / l, dz / l};
    }

    /** Lịch sử của một mục tiêu di chuyển thẳng đều; vị trí tại tick (T-k) = base + v*(m-k)*u, với base là vị trí client thấy (m tick trước). */
    static History victimHistory(double bx, double bz, double ux, double uz, double v, int m) {
        History h = new History();
        for (int k = 1; k <= 40; k++) {
            double s = v * (m - k);
            h.put(new Snapshot(T - k, bx + ux * s, 0, bz + uz * s, 0, 0, EYE, 0.6, 1.8));
        }
        return h;
    }
    static Aabb victimNow(double bx, double bz, double ux, double uz, double v, int m) {
        double s = v * m;
        return Aabb.ofFeet(bx + ux * s, 0, bz + uz * s, 0.6, 1.8);
    }

    public static void main(String[] a) {
        reach(); hitbox(); angle(); multi(); wall(); useItem(); snap(); noSwing(); trigger(); clicks(); cart();
        System.out.println("\nKết quả: " + passed + " đạt, " + failed + " lỗi");
        System.exit(failed == 0 ? 0 : 1);
    }

    // ------------------------------------------------------------------ Reach
    static void reach() {
        System.out.println("\n[Reach]");
        CheckSettings s = cs(Check.REACH);
        PlayerData d = pd();
        int flags = 0, hits = 4000;
        for (int i = 0; i < hits; i++) {
            double pingTrue = R.nextDouble() * 250;
            int m = (int) Math.round(pingTrue / 50.0) + R.nextInt(3);
            double pingEst = Math.max(0, pingTrue + (R.nextDouble() * 80 - 40));
            int lag = CombatChecks.lagTicks((int) pingEst, 300);
            double ang = R.nextDouble() * Math.PI * 2;
            double ux = Math.cos(ang), uz = Math.sin(ang);
            double v = R.nextDouble() * 0.3;
            double distClient = 1.0 + R.nextDouble() * 2.0;            // ≤ 3.0 (hợp lệ trên máy khách)
            double bx = distClient + 0.3, bz = 0;                       // mục tiêu phía +x
            History vh = victimHistory(bx, bz, ux, uz, v, m);
            Aabb now = victimNow(bx, bz, ux, uz, v, m);
            List<Aabb> boxes = CombatChecks.rewind(now, vh, T, lag);
            if (CombatChecks.reach(d, s, 3.0, 0, EYE, 0, boxes, (int) pingEst).flagged()) flags++;
        }
        ok(flags == 0, hits + " cú đánh hợp lệ (ping 0–250ms, sai số ping ±40ms, mục tiêu chạy tới 0.3 b/t): 0 flag");

        for (double reach : new double[] {3.6, 3.3}) {
            PlayerData d2 = pd(); int f = 0;
            for (int i = 0; i < 30; i++) {
                History vh = victimHistory(reach + 0.3, 0, 1, 0, 0, 2);
                if (CombatChecks.reach(d2, s, 3.0, 0, EYE, 0, CombatChecks.rewind(victimNow(reach + 0.3, 0, 1, 0, 0, 2), vh, T, 1), 50).flagged()) f++;
            }
            ok(f >= 1, "reach hack " + reach + " block (mục tiêu đứng yên) bị bắt");
        }
        { PlayerData d3 = pd(); int f = 0;
          for (int i = 0; i < 100; i++) if (CombatChecks.reach(d3, s, 3.0, 0, EYE, 0, List.of(Aabb.ofFeet(3.1 + 0.3, 0, 0, 0.6, 1.8)), 30).flagged()) f++;
          ok(f == 0, "3.1 block (trong dung sai 0.12) không bị flag"); }
        { PlayerData d4 = pd(); int f = 0; // hack khi mục tiêu bỏ chạy, ping 0
          for (int i = 0; i < 30; i++) { History vh = victimHistory(4.6, 0, 1, 0, 0.2, 0); if (CombatChecks.reach(d4, s, 3.0, 0, EYE, 0, CombatChecks.rewind(victimNow(4.6, 0, 1, 0, 0.2, 0), vh, T, 0), 0).flagged()) f++; }
          ok(f >= 1, "reach hack ~4.3 block khi mục tiêu bỏ chạy, ping 0 bị bắt"); }
        { PlayerData d5 = pd(); int f = 0;
          for (int i = 0; i < 100; i++) if (CombatChecks.reach(d5, s, 5.0, 0, EYE, 0, List.of(Aabb.ofFeet(4.9 + 0.3, 0, 0, 0.6, 1.8)), 40).flagged()) f++;
          ok(f == 0, "creative (tầm 5.0 từ attribute) đánh 4.9 không bị flag"); }
        { PlayerData d6 = pd(); int f = 0; // 1/10 cú đánh vượt do ping spike
          for (int i = 0; i < 600; i++) { double dist = (i % 10 == 0) ? 3.6 : 2.8; if (CombatChecks.reach(d6, s, 3.0, 0, EYE, 0, List.of(Aabb.ofFeet(dist + 0.3, 0, 0, 0.6, 1.8)), 40).flagged()) f++; }
          ok(f == 0, "thỉnh thoảng 1/10 cú vượt tầm (spike) không bị flag"); }
    }

    // ------------------------------------------------------------------ Hitbox
    static void hitbox() {
        System.out.println("\n[Hitbox]");
        CheckSettings s = cs(Check.HITBOX);
        PlayerData d = pd();
        int flags = 0, hits = 4000;
        for (int i = 0; i < hits; i++) {
            double pingTrue = R.nextDouble() * 250;
            int m = (int) Math.round(pingTrue / 50.0) + R.nextInt(3);
            int lag = CombatChecks.lagTicks((int) Math.max(0, pingTrue + (R.nextDouble() * 80 - 40)), 300);
            double ang = R.nextDouble() * Math.PI * 2, v = R.nextDouble() * 0.3;
            double ux = Math.cos(ang), uz = Math.sin(ang);
            double distClient = 1.0 + R.nextDouble() * 2.0;
            double bx = distClient + 0.3, bz = 0;
            History vh = victimHistory(bx, bz, ux, uz, v, m);
            Aabb now = victimNow(bx, bz, ux, uz, v, m);
            // điểm ngắm ngẫu nhiên BÊN TRONG hộp mà máy khách thấy (vị trí m tick trước)
            Aabb seen = Aabb.ofFeet(bx + ux * 0, 0, bz + uz * 0, 0.6, 1.8);
            seen = victimBoxClient(bx, bz, ux, uz, v, m);
            double px = seen.minX() + R.nextDouble() * (seen.maxX() - seen.minX());
            double py = seen.minY() + R.nextDouble() * (seen.maxY() - seen.minY());
            double pz = seen.minZ() + R.nextDouble() * (seen.maxZ() - seen.minZ());
            double[] yp = yawPitch(px, py - EYE, pz);
            yp[0] += (R.nextDouble() - 0.5) * 0.3; yp[1] += (R.nextDouble() - 0.5) * 0.3;   // nhiễu ±0.15°
            double[] look = Look.dir((float) yp[0], (float) yp[1]);
            if (CombatChecks.hitbox(d, s, 0, EYE, 0, look, 0.5, 0.5, CombatChecks.rewind(now, vh, T, lag), 5.0).flagged()) flags++;
        }
        ok(flags == 0, hits + " cú đánh hợp lệ (ngắm ngẫu nhiên trong hitbox, ping, nhiễu xoay): 0 flag");

        for (double out : new double[] {0.5, 0.3, 0.2}) {
            PlayerData d2 = pd(); int f = 0;
            for (int i = 0; i < 30; i++) {
                Aabb box = Aabb.ofFeet(3.3, 0, 0, 0.6, 1.8);
                double[] yp = yawPitch(3.3, 0.9 - EYE, 0.3 + out);   // điểm ngắm lệch ra ngoài mép hộp "out" block
                double[] look = Look.dir((float) yp[0], (float) yp[1]);
                if (CombatChecks.hitbox(d2, s, 0, EYE, 0, look, 0.3, 0.3, List.of(box), 5.0).flagged()) f++;
            }
            ok(f >= 1, "hitbox hack nới " + out + " block bị bắt");
        }
        { PlayerData d3 = pd(); int f = 0;
          for (int i = 0; i < 100; i++) { double[] yp = yawPitch(3.3, 0.9 - EYE, 0.3 + 0.08); if (CombatChecks.hitbox(d3, s, 0, EYE, 0, Look.dir((float) yp[0], (float) yp[1]), 0.3, 0.3, List.of(Aabb.ofFeet(3.3, 0, 0, 0.6, 1.8)), 5.0).flagged()) f++; }
          ok(f == 0, "lệch 0.08 block ngoài mép (trong dung sai) không bị flag"); }
        { PlayerData d4 = pd(); int f = 0;
          for (int i = 0; i < 100; i++) { double[] yp = yawPitch(3.3, 0.9 - EYE, 1.5); if (CombatChecks.hitbox(d4, s, 0, EYE, 0, Look.dir((float) yp[0], (float) yp[1]), 12.0, 0.3, List.of(Aabb.ofFeet(3.3, 0, 0, 0.6, 1.8)), 5.0).flagged()) f++; }
          ok(f == 0 && d4.buffer(Check.HITBOX) == 0, "đang xoay nhanh (12°/tick): bỏ qua, không tích bộ đệm"); }
    }
    static Aabb victimBoxClient(double bx, double bz, double ux, double uz, double v, int m) { return Aabb.ofFeet(bx, 0, bz, 0.6, 1.8); }

    // ------------------------------------------------------------------ KillAura: Angle
    static void angle() {
        System.out.println("\n[KillAura — Angle]");
        CheckSettings s = cs(Check.KILLAURA_ANGLE);
        List<Aabb> box = List.of(Aabb.ofFeet(3, 0, 0, 0.6, 1.8));
        PlayerData d = pd(); int f = 0;
        for (int i = 0; i < 400; i++) { double deg = Math.toRadians(30); if (CombatChecks.angle(d, s, 0, EYE, 0, new double[] {Math.cos(deg), 0, Math.sin(deg)}, null, box).flagged()) f++; }
        ok(f == 0, "đánh liên tục khi hướng nhìn lệch 30° (trong hình cầu bao + dung sai): 0 flag");
        PlayerData d2 = pd(); f = 0;
        for (int i = 0; i < 20; i++) if (CombatChecks.angle(d2, s, 0, EYE, 0, new double[] {0, 0, 1}, null, box).flagged()) f++;
        ok(f >= 1, "đánh khi nhìn lệch 90° bị bắt");
        PlayerData d3 = pd(); f = 0;
        for (int i = 0; i < 20; i++) if (CombatChecks.angle(d3, s, 0, EYE, 0, new double[] {-1, 0, 0}, null, box).flagged()) f++;
        ok(f >= 1, "đánh mục tiêu phía sau lưng bị bắt");
        PlayerData d4 = pd(); f = 0;
        for (int i = 0; i < 400; i++) { double deg = Math.toRadians(i % 10 == 0 ? 90 : 5); if (CombatChecks.angle(d4, s, 0, EYE, 0, new double[] {Math.cos(deg), 0, Math.sin(deg)}, null, box).flagged()) f++; }
        ok(f == 0, "thỉnh thoảng 1/10 cú đánh lệch (spike) không bị flag");
        PlayerData d5 = pd(); f = 0; // đang flick: hướng ở tick trước đúng mục tiêu → được chấp nhận
        for (int i = 0; i < 50; i++) if (CombatChecks.angle(d5, s, 0, EYE, 0, new double[] {0, 0, 1}, new double[] {1, 0, 0}, box).flagged()) f++;
        ok(f == 0, "hướng ở tick trước đúng mục tiêu (flick/trễ gói xoay) được chấp nhận");
    }

    // ------------------------------------------------------------------ Multi
    static void multi() {
        System.out.println("\n[KillAura — Multi]");
        CheckSettings s = cs(Check.KILLAURA_MULTI);
        PlayerData d = pd(); int f = 0; long t = 9_000_000_000L;
        for (int i = 0; i < 400; i++) { t += 50_000_000L + R.nextInt(20_000_000); if (CombatChecks.multi(d, s, 7, 1, 0, 0, t).flagged()) f++; }
        ok(f == 0, "đánh liên tục MỘT mục tiêu: 0 flag");
        PlayerData d2 = pd(); f = 0; t = 9_000_000_000L;
        for (int i = 0; i < 100; i++) { t += 50_000_000L; int id = 1 + i % 2; double ang = Math.toRadians(20); if (CombatChecks.multi(d2, s, id, id == 1 ? 1 : Math.cos(ang), 0, id == 1 ? 0 : Math.sin(ang), t).flagged()) f++; }
        ok(f == 0, "đổi mục tiêu nhanh khi hai mục tiêu đứng cạnh nhau (20°): 0 flag");
        PlayerData d3 = pd(); f = 0; t = 9_000_000_000L;
        for (int i = 0; i < 20; i++) { t += 200_000_000L; int id = 1 + i % 2; if (CombatChecks.multi(d3, s, id, id == 1 ? 1 : -1, 0, 0, t).flagged()) f++; }
        ok(f == 0, "đổi qua lại hai mục tiêu đối diện cách 200ms (người thật): 0 flag");
        PlayerData d4 = pd(); f = 0; t = 9_000_000_000L;
        for (int i = 0; i < 12; i++) { t += 5_000_000L; int id = 1 + i % 2; if (CombatChecks.multi(d4, s, id, id == 1 ? 1 : -1, 0, 0, t).flagged()) f++; }
        ok(f >= 1, "multi-aura: hai mục tiêu đối diện trong vài ms bị bắt");
        PlayerData d5 = pd(); f = 0; t = 9_000_000_000L; // một lần gói dồn do lag
        for (int i = 0; i < 100; i++) { t += 300_000_000L; if (CombatChecks.multi(d5, s, 1, 1, 0, 0, t).flagged()) f++; if (i == 50) { t += 1_000_000L; if (CombatChecks.multi(d5, s, 2, -1, 0, 0, t).flagged()) f++; } }
        ok(f == 0, "một lần gói dồn do lag (1 cặp): 0 flag");
    }

    // ------------------------------------------------------------------ Wall / UseItem
    static void wall() {
        System.out.println("\n[KillAura — Wall]");
        CheckSettings s = cs(Check.KILLAURA_WALL);
        PlayerData d = pd(); int f = 0;
        for (int i = 0; i < 400; i++) if (CombatChecks.wall(d, s, i % 8 == 0 ? 1.5 : -1, 3.0).flagged()) f++;
        ok(f == 0, "thỉnh thoảng 1/8 cú đánh sát góc tường: 0 flag");
        PlayerData d2 = pd(); f = 0;
        for (int i = 0; i < 20; i++) if (CombatChecks.wall(d2, s, 1.5, 3.0).flagged()) f++;
        ok(f >= 1, "đánh xuyên tường liên tục bị bắt");
        PlayerData d3 = pd(); f = 0;
        for (int i = 0; i < 50; i++) if (CombatChecks.wall(d3, s, 0.3, 0.6).flagged()) f++;
        ok(f == 0, "mục tiêu sát người (<1 block): bỏ qua");
        PlayerData d4 = pd(); f = 0;
        for (int i = 0; i < 100; i++) if (CombatChecks.wall(d4, s, 2.9, 3.0).flagged()) f++;
        ok(f == 0, "khối chắn sát mép mục tiêu (trong dung sai 0.25): 0 flag");
    }

    static void useItem() {
        System.out.println("\n[KillAura — UseItem]");
        CheckSettings s = cs(Check.KILLAURA_ITEM);
        PlayerData d = pd(); int f = 0;
        for (int i = 0; i < 300; i++) if (CombatChecks.useItem(d, s, i % 20 == 0).flagged()) f++;
        ok(f == 0, "thỉnh thoảng 1/20 cú (lệch trạng thái do trễ): 0 flag");
        PlayerData d2 = pd(); f = 0;
        for (int i = 0; i < 10; i++) if (CombatChecks.useItem(d2, s, true).flagged()) f++;
        ok(f >= 1, "đánh liên tục khi đang giơ khiên/ăn bị bắt");
    }

    // ------------------------------------------------------------------ Snap
    static void snap() {
        System.out.println("\n[KillAura — Snap (silent rotation)]");
        CheckSettings s = cs(Check.KILLAURA_SNAP);
        double[] before = Look.dir(-90, 0), atHit = Look.dir(0, 0), back = Look.dir(-88, 1);
        PlayerData d = pd(); int f = 0; long t = 5_000_000_000L;
        for (int i = 0; i < 6; i++) {
            t += 1_000_000_000L;
            CombatChecks.snapStart(d, s, t, before, atHit);
            if (CombatChecks.snapResolve(d, s, t + 10_000_000L, back).flagged()) f++;
        }
        ok(f >= 1, "xoay 90° để đánh rồi quay về hướng cũ ngay: bị bắt");
        PlayerData d2 = pd(); f = 0; t = 5_000_000_000L;
        for (int i = 0; i < 300; i++) {
            t += 1_000_000_000L;
            CombatChecks.snapStart(d2, s, t, before, atHit);       // flick tới mục tiêu và ở lại đó
            for (int k = 1; k <= 5; k++) if (CombatChecks.snapResolve(d2, s, t + k * 50_000_000L, atHit).flagged()) f++;
        }
        ok(f == 0, "flick tới mục tiêu rồi tiếp tục nhìn mục tiêu (người thật): 0 flag");
        PlayerData d3 = pd(); f = 0; t = 5_000_000_000L;
        for (int i = 0; i < 300; i++) {
            t += 1_000_000_000L;
            CombatChecks.snapStart(d3, s, t, before, Look.dir(-60, 0));      // xoay 30° < 45°: không theo dõi
            if (CombatChecks.snapResolve(d3, s, t + 10_000_000L, back).flagged()) f++;
        }
        ok(f == 0, "xoay nhỏ (30°) không bị theo dõi: 0 flag");
    }

    // ------------------------------------------------------------------ NoSwing
    static void noSwing() {
        System.out.println("\n[NoSwing]");
        CheckSettings s = cs(Check.NOSWING);
        PlayerData d = pd(); int f = 0; long t = 3_000_000_000L;
        for (int i = 0; i < 300; i++) {
            t += 400_000_000L;
            CombatChecks.hit(d, s, t);
            t += 5_000_000L;
            CombatChecks.swing(d, s, t);                                  // 1.9+: vung tay đến sau cú đánh
            if (CombatChecks.noSwingTick(d, s, t + 100_000_000L).flagged()) f++;
        }
        ok(f == 0, "vung tay đến ngay sau cú đánh (1.9+): 0 flag");
        PlayerData d2 = pd(); f = 0; t = 3_000_000_000L;
        for (int i = 0; i < 300; i++) {
            t += 400_000_000L;
            CombatChecks.swing(d2, s, t);                                 // 1.8 (ViaVersion): vung tay trước
            t += 8_000_000L;
            CombatChecks.hit(d2, s, t);
            if (CombatChecks.noSwingTick(d2, s, t + 100_000_000L).flagged()) f++;
        }
        ok(f == 0, "vung tay đến trước cú đánh (1.8 qua ViaVersion): 0 flag");
        PlayerData d3 = pd(); f = 0; t = 3_000_000_000L;
        for (int i = 0; i < 8; i++) {
            t += 600_000_000L;
            CombatChecks.hit(d3, s, t);
            if (CombatChecks.noSwingTick(d3, s, t + 300_000_000L).flagged()) f++;
        }
        ok(f >= 1, "đánh liên tục không vung tay bị bắt");
    }

    // ------------------------------------------------------------------ TriggerBot
    static int runFor(int delay) {
        // mục tiêu chạy chậm ngang qua tâm ngắm (người đánh đứng yên nhìn +x, mục tiêu ở x=3 đi theo trục z)
        final long tStart = 400;
        final double speed = 0.05, z0 = -1.0;
        int enter = -1;
        for (int n = 0; n < 60; n++) {
            double z = z0 + speed * n;
            if (Aabb.ofFeet(3, 0, z, 0.6, 1.8).inflate(0.12).rayHits(0, EYE, 0, 1, 0, 0, 12)) { enter = n; break; }
        }
        long tick = tStart + enter + delay;
        History ah = new History(), vh = new History();
        for (long t = tStart; t <= tick; t++) {
            ah.put(new Snapshot(t, 0, 0, 0, -90f, 0f, EYE, 0.6, 1.8));
            vh.put(new Snapshot(t, 3, 0, z0 + speed * (t - tStart), 0, 0, EYE, 0.6, 1.8));
        }
        Snapshot aNow = ah.at(tick);
        Aabb vNow = vh.at(tick).box();
        return CombatChecks.onTargetRun(ah, aNow, vh, vNow, tick, 0, 0.12, 8);
    }

    static void trigger() {
        System.out.println("\n[TriggerBot]");
        CheckSettings s = cs(Check.TRIGGERBOT);
        ok(runFor(0) == 1, "đánh đúng tick tâm ngắm vừa vào hitbox: run = 1 (" + runFor(0) + ")");
        ok(runFor(5) == 6, "đánh sau 5 tick (250ms): run = 6 (" + runFor(5) + ")");

        PlayerData d = pd(); int f = 0; long t = 2_000_000_000L;
        for (int i = 0; i < 12; i++) {
            t += 2_000_000_000L;
            d.hasSwing = true; d.lastSwingNanos = t - 1_000_000_000L;
            if (CombatChecks.trigger(d, s, t, runFor(R.nextInt(2))).flagged()) f++;   // click ngay khi vào hitbox
        }
        ok(f == 1, "trigger bot: 12/12 cú đánh tức thì → flag đúng 1 lần ở cú thứ 12");

        PlayerData d2 = pd(); f = 0; t = 2_000_000_000L;
        for (int i = 0; i < 2000; i++) {
            t += 2_000_000_000L;
            d2.hasSwing = true; d2.lastSwingNanos = t - 1_000_000_000L;
            int delay = R.nextInt(100) < 15 ? R.nextInt(2) : 3 + R.nextInt(10);       // 15% pre-click, còn lại phản xạ 150–650ms
            if (CombatChecks.trigger(d2, s, t, runFor(delay)).flagged()) f++;
        }
        ok(f == 0, "2000 cú đánh người thật (15% click sớm): 0 flag");

        PlayerData d3 = pd(); f = 0; t = 2_000_000_000L;
        for (int i = 0; i < 500; i++) {
            t += 100_000_000L;                                                         // spam click 10 CPS
            d3.hasSwing = true; d3.lastSwingNanos = t - 100_000_000L;
            if (CombatChecks.trigger(d3, s, t, runFor(R.nextInt(2))).flagged()) f++;
        }
        ok(f == 0, "spam click (cách click trước < 500ms) không đủ điều kiện: 0 flag");

        PlayerData d4 = pd(); f = 0; t = 2_000_000_000L;
        for (int i = 0; i < 400; i++) {                                                // người đã ngắm sẵn mục tiêu rồi mới đánh
            t += 2_000_000_000L;
            d4.hasSwing = true; d4.lastSwingNanos = t - 1_000_000_000L;
            if (CombatChecks.trigger(d4, s, t, runFor(8 + R.nextInt(4))).flagged()) f++;
        }
        ok(f == 0, "tâm ngắm đã ở trên mục tiêu từ lâu rồi mới đánh: 0 flag");
    }

    // ------------------------------------------------------------------ AutoClicker
    static void clicks() {
        System.out.println("\n[AutoClicker]");
        CheckSettings cps = cs(Check.AUTOCLICKER_CPS), pat = cs(Check.AUTOCLICKER_PATTERN);
        for (int rate : new int[] {8, 15, 20}) {
            PlayerData d = pd(); int f = 0; long t = 5_000_000_000L; double gap = 1e9 / rate;
            for (int i = 0; i < rate * 30; i++) { t += (long) gap; if (ClickChecks.cps(d, cps, t).flagged()) f++; }
            ok(f == 0, "click " + rate + " CPS trong 30 giây: 0 flag");
        }
        { PlayerData d = pd(); int f = 0; long t = 7_000_000_000L;
          for (int i = 0; i < 20 * 60; i++) { t += (long) (1e9 / 20 * (0.7 + 0.6 * R.nextDouble())); if (ClickChecks.cps(d, cps, t).flagged()) f++; }
          ok(f == 0, "click ~20 CPS có dao động (butterfly): 0 flag"); }
        { PlayerData d = pd(); int f = 0; long t = -3_000_000_000L;
          for (int i = 0; i < 30 * 12; i++) { t += 1_000_000_000L / 30; if (ClickChecks.cps(d, cps, t).flagged()) f++; }
          ok(f >= 1, "autoclicker 30 CPS bị bắt (kể cả khi nanoTime âm)"); }
        { PlayerData d = pd(); int f = 0; long t = 1_000_000_000L;
          for (int i = 0; i < 60; i++) { t += 1_000_000_000L / 30; if (ClickChecks.cps(d, cps, t).flagged()) f++; }
          ok(f == 0, "vượt CPS thoáng qua 2 giây: chưa flag"); }

        // mẫu click theo tick
        { PlayerData d = pd(); int f = 0; long tick = 100;
          for (int i = 0; i < 2000; i++) { tick += 1 + R.nextInt(3); if (ClickChecks.pattern(d, pat, tick).flagged()) f++; }   // 1–3 tick, trung bình 2
          ok(f == 0, "click ~10 CPS có dao động tự nhiên (2000 click): 0 flag"); }
        { PlayerData d = pd(); int f = 0; long tick = 100;
          for (int i = 0; i < 400; i++) { tick += 2; if (ClickChecks.pattern(d, pat, tick).flagged()) f++; }
          ok(f >= 1, "macro đều tuyệt đối 10 CPS bị bắt"); }
        { PlayerData d = pd(); int f = 0; long tick = 100;
          for (int i = 0; i < 400; i++) { tick += 3; if (ClickChecks.pattern(d, pat, tick).flagged()) f++; }
          ok(f == 0, "đều nhưng chỉ 6.7 CPS (dưới ngưỡng phân tích): 0 flag"); }
        { PlayerData d = pd(); int f = 0; long tick = 100;   // click theo từng đợt có nghỉ, đợt nào cũng đều nhưng ngắn
          for (int burst = 0; burst < 100; burst++) { for (int i = 0; i < 20; i++) { tick += 2; if (ClickChecks.pattern(d, pat, tick).flagged()) f++; } tick += 30; }
          ok(f == 0, "các đợt click ngắn (20 click) có nghỉ: 0 flag"); }
    }

    // ------------------------------------------------------------------ AutoCart
    static final long MS = 1_000_000L;
    static void cart() {
        System.out.println("\n[AutoCart]");
        CheckSettings seq = cs(Check.AUTOCART_SEQUENCE), rate = cs(Check.AUTOCART_RATE);
        { PlayerData d = pd(); int f = 0; long t = 10_000_000_000L;
          for (int i = 0; i < 200; i++) { t += 5000 * MS;
              { int cm = 300 + R.nextInt(300); f += cartRun(d, seq, rate, t, 0, cm, cm + 200 + R.nextInt(300)); } }
          ok(f == 0, "chơi bình thường (ray → xe 0.3–0.6s → châm 0.5–0.9s): 0 flag"); }
        { PlayerData d = pd(); int f = 0; long t = 10_000_000_000L;
          for (int i = 0; i < 200; i++) { t += 5000 * MS; f += cartRun(d, seq, rate, t, 0, 150, 320); }
          ok(f == 0, "người chơi rất nhanh (ray→xe 150ms, xe→châm 170ms): 0 flag"); }
        { PlayerData d = pd(); int f = 0; long t = 10_000_000_000L;
          for (int i = 0; i < 6; i++) { t += 5000 * MS; f += cartRun(d, seq, rate, t, 0, 50, 100); }
          ok(f >= 1, "autocart: ray→xe 50ms, xe→châm 50ms bị bắt"); }
        { PlayerData d = pd(); int f = 0; long t = 10_000_000_000L;
          for (int i = 0; i < 8; i++) { t += 5000 * MS; f += cartRun(d, seq, rate, t, -1, 0, 40); }   // ray đặt từ trước, xe→châm 40ms
          ok(f >= 1, "xe→châm quá nhanh (40ms), lặp lại bị bắt"); }
        { PlayerData d = pd(); int f = 0; long t = 10_000_000_000L;
          f += cartRun(d, seq, rate, t + 5000 * MS, 0, 50, 100);                                           // một chuỗi nhanh do lag dồn gói
          for (int i = 0; i < 20; i++) { t += 10000 * MS; f += cartRun(d, seq, rate, t, 0, 400, 800); }
          ok(f == 0, "một chuỗi nhanh đơn lẻ do lag (rồi chơi bình thường): 0 flag"); }
        { PlayerData d = pd(); int f = 0; long t = 10_000_000_000L;
          for (int i = 0; i < 40; i++) { t += 200 * MS; f += run(d, seq, rate, CartChecks.Event.RAIL, t); }    // 5 ray/giây (giữ chuột phải)
          ok(f == 0, "đặt ray 5 cái/giây: 0 flag"); }
        { PlayerData d = pd(); int f = 0; long t = 10_000_000_000L;
          for (int i = 0; i < 60; i++) { t += 50 * MS; f += run(d, seq, rate, CartChecks.Event.RAIL, t); }    // 20 ray/giây
          ok(f >= 1, "đặt ray 20 cái/giây bị bắt"); }
        { PlayerData d = pd(); int f = 0; long t = 10_000_000_000L;
          for (int i = 0; i < 60; i++) { t += 60 * MS; f += run(d, seq, rate, CartChecks.Event.TNT, t); }     // ~16 TNT/giây
          ok(f >= 1, "đặt TNT ~16 cái/giây bị bắt"); }
        { PlayerData d = pd(); int f = 0; long t = 10_000_000_000L;
          for (int i = 0; i < 60; i++) { t += 50 * MS; f += run(d, seq, rate, CartChecks.Event.IGNITE_OTHER, t); }  // 20 lần châm/giây
          ok(f >= 1, "châm lửa 20 lần/giây bị bắt"); }
        { PlayerData d = pd(); int f = 0; long t = 10_000_000_000L;
          for (int i = 0; i < 40; i++) { t += 100 * MS; f += run(d, seq, rate, CartChecks.Event.IGNITE_OTHER, t); }  // 10 lần/giây
          ok(f == 0, "châm lửa 10 lần/giây (giới hạn): 0 flag"); }
        { PlayerData d = pd(); int f = 0; long t = 10_000_000_000L;   // người chơi chỉ bắn xe bằng cung: không có sự kiện nào
          ok(f == 0, "bắn xe bằng cung/tên lửa: không có sự kiện đặt/châm nên không bao giờ bị theo dõi"); }
    }

    static int run(PlayerData d, CheckSettings seq, CheckSettings rate, CartChecks.Event e, long now) {
        int f = 0;
        for (Verdict v : CartChecks.on(d, e, now, seq, rate)) if (v.flagged()) f++;
        return f;
    }

    /** railOffset >= 0: ray đặt tại t; rồi xe sau cartMs; rồi châm sau igniteMs-cartMs. railOffset < 0: không đặt ray (đã có từ trước). */
    static int cartRun(PlayerData d, CheckSettings seq, CheckSettings rate, long t, int railOffset, int cartMs, int igniteMs) {
        int f = 0;
        if (railOffset >= 0) f += run(d, seq, rate, CartChecks.Event.RAIL, t);
        long tc = t + cartMs * MS;
        f += run(d, seq, rate, CartChecks.Event.CART, tc);
        f += run(d, seq, rate, CartChecks.Event.IGNITE_CART, t + igniteMs * MS + (railOffset < 0 ? cartMs * MS : 0));
        return f;
    }
}
