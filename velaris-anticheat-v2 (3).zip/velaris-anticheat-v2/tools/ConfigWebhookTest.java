package com.velaris.anticheat.core;

import com.sun.net.httpserver.HttpServer;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;

public class ConfigWebhookTest {
    static int pass, fail;
    static void ok(boolean c, String m) { if (c) pass++; else fail++; System.out.println((c ? "  ✓ " : "  ✗ ") + m); }

    /** YAML con: map lồng nhau theo thụt lề, scalar, [] rỗng, danh sách "- x". */
    static Map<String, Object> yaml(String text) {
        Map<String, Object> root = new LinkedHashMap<>();
        Deque<Map<String, Object>> stack = new ArrayDeque<>(); Deque<Integer> ind = new ArrayDeque<>();
        stack.push(root); ind.push(-1);
        String emptyKey = null; Map<String, Object> emptyParent = null;
        for (String raw : text.split("\n")) {
            String line = raw.stripTrailing();
            if (line.isBlank() || line.stripLeading().startsWith("#")) continue;
            int n = line.length() - line.stripLeading().length();
            String t = line.strip();
            if (t.startsWith("- ")) {
                if (!(emptyParent.get(emptyKey) instanceof List)) { stack.pop(); ind.pop(); emptyParent.put(emptyKey, new ArrayList<>()); }
                ((List<Object>) emptyParent.get(emptyKey)).add(scalar(t.substring(2))); continue; }
            while (ind.peek() >= n) { stack.pop(); ind.pop(); }
            int c = t.indexOf(':'); String k = t.substring(0, c).trim(); String v = t.substring(c + 1).trim();
            Map<String, Object> cur = stack.peek();
            if (v.isEmpty()) { Map<String, Object> m = new LinkedHashMap<>(); cur.put(k, m); stack.push(m); ind.push(n); emptyKey = k; emptyParent = cur; }
            else cur.put(k, scalar(v));
        }
        return root;
    }
    static Object scalar(String v) {
        if (v.equals("[]")) return new ArrayList<>();
        if (v.equals("true")) return true; if (v.equals("false")) return false;
        try { return Double.parseDouble(v); } catch (NumberFormatException e) { return v.replace("\"", ""); }
    }
    static Source src(Map<String, Object> m) {
        return path -> { Object cur = m; for (String p : path.split("\\.")) { if (!(cur instanceof Map<?, ?> mm)) return null; cur = mm.get(p); } return cur; };
    }

    public static void main(String[] a) throws Exception {
        System.out.println("[Cấu hình YAML riêng]");
        ok(DefaultFiles.files().equals(List.of("reach.yml", "hitbox.yml", "killaura.yml", "triggerbot.yml", "autoclicker.yml", "autocart.yml")), "6 file riêng: " + DefaultFiles.files());
        List<String> warns = new ArrayList<>();
        for (String f : DefaultFiles.files()) {
            Source s = src(yaml(DefaultFiles.render(f)));
            for (Check c : Check.values()) if (c.file().equals(f)) {
                CheckSettings got = CheckSettings.load(s, c.section() == null ? "" : c.section() + ".", c, warns::add);
                CheckSettings def = CheckSettings.defaults(c);
                boolean same = got.params.equals(def.params) && got.enabled && got.alert && got.discord && got.weight == 1.0 && got.punishVl == 0 && got.commands.isEmpty();
                ok(same, f + " → " + c.display() + " nạp lại đúng bằng mặc định");
            }
        }
        ok(warns.isEmpty(), "file mặc định không sinh cảnh báo nào: " + warns);

        warns.clear();
        Map<String, Object> bad = yaml("enabled: yes-sir\nvl-weight: -3\npunish:\n  vl: -1\n  commands: 5\nsettings:\n  extra: abc\n  buffer: -2\n  ping-cap-ms: 120\n");
        CheckSettings r = CheckSettings.load(src(bad), "", Check.REACH, warns::add);
        ok(r.enabled && r.weight == 1.0 && r.punishVl == 0, "giá trị sai kiểu/âm → dùng mặc định");
        ok(r.p("extra") == 0.12 && r.p("buffer") == 3.0 && r.p("ping-cap-ms") == 120.0, "tham số hợp lệ được nhận, sai thì giữ mặc định");
        ok(warns.size() == 6, "báo đủ 6 cảnh báo: " + warns.size());
        CheckSettings e = CheckSettings.load(src(new HashMap<>()), "", Check.HITBOX, warns::add);
        ok(e.p("expand") == 0.12, "file rỗng → toàn bộ mặc định");

        Map<String, Object> cust = yaml("enabled: false\nalert: false\nvl-weight: 2.5\npunish:\n  vl: 30\n  commands:\n    - kick %player% bye\n    - ban %player%\n");
        CheckSettings cs = CheckSettings.load(src(cust), "", Check.REACH, warns::add);
        ok(!cs.enabled && !cs.alert && cs.weight == 2.5 && cs.punishVl == 30 && cs.commands.equals(List.of("kick %player% bye", "ban %player%")), "tuỳ chỉnh đọc đúng");

        System.out.println("\n[Webhook Discord]");
        ok(DiscordWebhook.validUrl("https://discord.com/api/webhooks/1/abc", false), "URL discord.com hợp lệ");
        ok(DiscordWebhook.validUrl("https://discordapp.com/api/webhooks/1/abc", false), "URL discordapp.com hợp lệ");
        ok(!DiscordWebhook.validUrl("http://discord.com/api/webhooks/1/abc", false), "http bị từ chối");
        ok(!DiscordWebhook.validUrl("https://evil.com/api/webhooks/1/abc", false), "host lạ bị từ chối");
        ok(!DiscordWebhook.validUrl("https://discord.com.evil.com/api/webhooks/1/a", false), "discord.com.evil.com bị từ chối");
        ok(!DiscordWebhook.validUrl("https://discord.com/other", false), "sai đường dẫn bị từ chối");
        ok(!DiscordWebhook.validUrl("", false) && !DiscordWebhook.validUrl(null, false) && !DiscordWebhook.validUrl("not a url", false), "rỗng/null/rác bị từ chối");

        // máy chủ giả: lần 1 trả 429 retry_after 0.3, sau đó 204
        List<String> bodies = new CopyOnWriteArrayList<>(); AtomicInteger hits = new AtomicInteger();
        HttpServer srv = HttpServer.create(new InetSocketAddress("127.0.0.1", 0), 0);
        srv.createContext("/api/webhooks/1/x", ex -> {
            byte[] body = ex.getRequestBody().readAllBytes();
            int n = hits.incrementAndGet();
            if (n == 1) { byte[] r429 = "{\"message\":\"rate\",\"retry_after\":0.3}".getBytes(); ex.sendResponseHeaders(429, r429.length); ex.getResponseBody().write(r429); }
            else { bodies.add(new String(body, StandardCharsets.UTF_8)); ex.sendResponseHeaders(204, -1); }
            ex.close();
        });
        srv.start();
        String url = "http://127.0.0.1:" + srv.getAddress().getPort() + "/api/webhooks/1/x";
        String nasty = "Tên \"quote\" \\ back\nxuống dòng\ttab 😀 @everyone <@123> \u0001 ctl";
        try (DiscordWebhook w = new DiscordWebhook(url, "Velaris", "", 500, 100, true, System.out::println)) {
            for (int i = 0; i < 12; i++) {
                List<DiscordWebhook.Field> fs = List.of(new DiscordWebhook.Field("Người chơi", nasty, true), new DiscordWebhook.Field("Dài", "x".repeat(3000), false), new DiscordWebhook.Field("", "", false));
                w.enqueue(new DiscordWebhook.Embed("Flag #" + i + " " + nasty, i % 2 == 0 ? nasty + "y".repeat(5000) : "", 0xFF5555, fs, "", "footer " + nasty, "2026-11-23T10:00:00Z"));
            }
            long end = System.currentTimeMillis() + 10_000;
            while (System.currentTimeMillis() < end && bodies.stream().mapToInt(b -> b.split("\"title\"", -1).length - 1).sum() < 12) Thread.sleep(100);
        }
        srv.stop(0);
        int embeds = bodies.stream().mapToInt(b -> b.split("\"title\"", -1).length - 1).sum();
        ok(hits.get() >= 2, "gặp 429 rồi gửi lại thành công (số request " + hits.get() + ")");
        ok(embeds == 12, "đủ 12 embed, không mất cái nào: " + embeds);
        ok(bodies.size() == 2 && bodies.stream().allMatch(b -> b.split("\"title\"", -1).length - 1 <= 10), "chia lô ≤10 embed/request (" + bodies.size() + " request)");
        ok(bodies.stream().allMatch(b -> b.contains("\"allowed_mentions\":{\"parse\":[]}")), "luôn có allowed_mentions rỗng");
        Path dir = Paths.get(System.getProperty("out", "/tmp/v2wh")); Files.createDirectories(dir);
        for (int i = 0; i < bodies.size(); i++) Files.writeString(dir.resolve("b" + i + ".json"), bodies.get(i), StandardCharsets.UTF_8);
        System.out.println("\nKết quả: " + pass + " đạt, " + fail + " lỗi");
        System.exit(fail == 0 ? 0 : 1);
    }
}
