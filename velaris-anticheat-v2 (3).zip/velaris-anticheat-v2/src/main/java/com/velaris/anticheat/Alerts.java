package com.velaris.anticheat;

import com.velaris.anticheat.core.Check;
import com.velaris.anticheat.core.CheckSettings;
import java.util.List;
import java.util.Locale;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.event.ClickEvent;
import net.kyori.adventure.text.event.HoverEvent;
import net.kyori.adventure.text.format.TextColor;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.text.minimessage.tag.Tag;
import net.kyori.adventure.text.minimessage.tag.resolver.Placeholder;
import net.kyori.adventure.text.minimessage.tag.resolver.TagResolver;
import org.bukkit.Location;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

/**
 * Cảnh báo trong game: một dòng gọn, màu theo mức độ, thanh VL, di chuột xem chi tiết, bấm để dịch chuyển tới người chơi.
 * Toàn bộ nội dung tuỳ chỉnh trong messages.yml (MiniMessage). Dữ liệu người chơi luôn chèn dạng văn bản thuần,
 * nên tên/chi tiết không thể chèn thẻ định dạng hay lệnh.
 */
final class Alerts {
    private static final MiniMessage MM = MiniMessage.miniMessage();

    private final Engine eng;
    private final String prefix;
    private final String format;
    private final String hover;
    private final String consoleFormat;
    private final boolean clickTp;

    Alerts(Engine eng, YamlConfiguration m) {
        this.eng = eng;
        this.prefix = m.getString("prefix", "");
        this.format = m.getString("alert.format", "<player> <check> <vl>");
        List<String> h = m.getStringList("alert.hover");
        this.hover = String.join("\n", h);
        this.consoleFormat = m.getString("alert.console", "<player> <check> VL <vl> <detail>");
        this.clickTp = m.getBoolean("alert.click-teleport", true);
    }

    String msg(String key) { return eng.messages.getString(key, key); }

    Component parse(String template, TagResolver... r) {
        return MM.deserialize(template, TagResolver.builder().resolvers(r).resolver(Placeholder.parsed("prefix", prefix)).build());
    }

    static TextColor severity(double vl) {
        if (vl < 5.0) return TextColor.fromHexString("#4ade80");
        if (vl < 15.0) return TextColor.fromHexString("#facc15");
        return TextColor.fromHexString("#f87171");
    }

    static int severityRgb(double vl) {
        if (vl < 5.0) return 0x4ADE80;
        if (vl < 15.0) return 0xFACC15;
        return 0xF87171;
    }

    static String bar(double vl, double max) {
        int n = (int) Math.max(0, Math.min(10, Math.round(vl / Math.max(1.0, max) * 10.0)));
        return "▮".repeat(n) + "▯".repeat(10 - n);
    }

    void send(Player p, Check check, CheckSettings cs, double vl, String detail) {
        double max = cs.punishVl > 0 ? cs.punishVl : 20.0;
        Location l = p.getLocation();
        TagResolver r = TagResolver.builder()
                .resolver(Placeholder.unparsed("player", p.getName()))
                .resolver(Placeholder.unparsed("check", check.display()))
                .resolver(Placeholder.unparsed("vl", String.format(Locale.ROOT, "%.1f", vl)))
                .resolver(Placeholder.unparsed("bar", bar(vl, max)))
                .resolver(Placeholder.unparsed("ping", Integer.toString(p.getPing())))
                .resolver(Placeholder.unparsed("detail", detail))
                .resolver(Placeholder.unparsed("world", l.getWorld() == null ? "?" : l.getWorld().getName()))
                .resolver(Placeholder.unparsed("pos", String.format(Locale.ROOT, "%.0f, %.0f, %.0f", l.getX(), l.getY(), l.getZ())))
                .resolver(Placeholder.unparsed("tps", String.format(Locale.ROOT, "%.1f", eng.tps())))
                .resolver(TagResolver.resolver("sev", Tag.styling(severity(vl))))
                .build();
        Component line = parse(format, r);
        if (!hover.isBlank()) line = line.hoverEvent(HoverEvent.showText(parse(hover, r)));
        if (clickTp) line = line.clickEvent(ClickEvent.runCommand("/velaris tp " + p.getName()));
        for (Player staff : eng.staff()) staff.sendMessage(line);
        if (eng.consoleAlerts) {
            String plain = consoleFormat
                    .replace("<player>", p.getName()).replace("<check>", check.display())
                    .replace("<vl>", String.format(Locale.ROOT, "%.1f", vl)).replace("<detail>", detail)
                    .replace("<ping>", Integer.toString(p.getPing()));
            eng.plugin().getLogger().info(plain);
        }
    }
}
