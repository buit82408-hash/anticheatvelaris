package com.velaris.anticheat.core;

import java.util.Deque;
import java.util.Locale;

/** AutoClicker: CPS tối đa và mẫu click quá đều. */
public final class ClickChecks {
    private ClickChecks() {}

    /** Ghi một cú vung tay; đánh giá CPS mỗi ~250ms. */
    public static Verdict cps(PlayerData d, CheckSettings s, long nowNanos) {
        if (!s.enabled) return Verdict.NONE;
        Deque<Long> q = d.clicks;
        q.addLast(nowNanos);
        while (!q.isEmpty() && nowNanos - q.peekFirst() >= 1_000_000_000L) q.pollFirst();
        while (q.size() > 200) q.pollFirst();
        if (d.evalInit && nowNanos - d.lastEvalNanos < 250_000_000L) return Verdict.NONE;
        d.evalInit = true;
        d.lastEvalNanos = nowNanos;
        final int cps = q.size();
        return Buffers.push(d, Check.AUTOCLICKER_CPS, s, cps > s.p("max-cps"), 1.0, 1.0, s.p("buffer"),
                () -> "cps=" + cps);
    }

    /**
     * Phân tích khoảng cách (tick) giữa các click liên tiếp. Người thật dao động; macro/autoclicker đều gần như tuyệt đối.
     * Dùng tick nguyên nên không bị ảnh hưởng bởi jitter mạng.
     */
    public static Verdict pattern(PlayerData d, CheckSettings s, long tick) {
        if (!s.enabled) return Verdict.NONE;
        if (d.hasLastClickTick) {
            long gap = tick - d.lastClickTick;
            if (gap > 10) d.gapN = 0; // ngắt quãng: bắt đầu lại
            else if (d.gapN < d.gaps.length) d.gaps[d.gapN++] = (int) gap;
        }
        d.lastClickTick = tick;
        d.hasLastClickTick = true;

        int need = (int) Math.min(120, Math.max(10, s.p("min-clicks")));
        if (d.gapN < need) return Verdict.NONE;
        double sum = 0;
        for (int i = 0; i < d.gapN; i++) sum += d.gaps[i];
        final double mean = sum / d.gapN;
        double var = 0;
        for (int i = 0; i < d.gapN; i++) var += (d.gaps[i] - mean) * (d.gaps[i] - mean);
        final double std = Math.sqrt(var / d.gapN);
        d.gapN = 0;
        final double cps = mean <= 0 ? 99.0 : 20.0 / mean;
        boolean v = cps >= s.p("min-cps") && std <= s.p("max-std");
        return Buffers.push(d, Check.AUTOCLICKER_PATTERN, s, v, 1.0, 1.0, s.p("buffer"),
                () -> String.format(Locale.ROOT, "click quá đều: %.1f CPS, độ lệch %.2f tick", cps, std));
    }
}
