package com.velaris.anticheat.core;

/** Tiện ích hướng nhìn (quy ước Minecraft: yaw 0 = +Z, pitch dương = nhìn xuống). */
public final class Look {
    private Look() {}

    public static double[] dir(float yaw, float pitch) {
        double y = Math.toRadians(yaw), p = Math.toRadians(pitch);
        double cp = Math.cos(p);
        return new double[] {-Math.sin(y) * cp, -Math.sin(p), Math.cos(y) * cp};
    }

    public static double angleDeg(double[] a, double[] b) {
        double la = Math.sqrt(a[0] * a[0] + a[1] * a[1] + a[2] * a[2]);
        double lb = Math.sqrt(b[0] * b[0] + b[1] * b[1] + b[2] * b[2]);
        if (la < 1e-9 || lb < 1e-9) return 0.0;
        double c = (a[0] * b[0] + a[1] * b[1] + a[2] * b[2]) / (la * lb);
        return Math.toDegrees(Math.acos(Math.max(-1.0, Math.min(1.0, c))));
    }

    /**
     * Góc lệch (độ) giữa hướng nhìn và hộp mục tiêu, đã trừ "hình nón" của hình cầu bao hộp.
     * 0 = hướng nhìn nằm trong hình cầu bao (rất khoan dung với lag và mục tiêu di chuyển).
     */
    public static double aimError(double[] look, double ex, double ey, double ez, Aabb box) {
        double vx = box.cx() - ex, vy = box.cy() - ey, vz = box.cz() - ez;
        double d = Math.sqrt(vx * vx + vy * vy + vz * vz);
        double r = box.radius();
        if (d <= r || d < 1e-6) return 0.0;
        double ang = angleDeg(look, new double[] {vx, vy, vz});
        double cone = Math.toDegrees(Math.asin(Math.min(1.0, r / d)));
        return Math.max(0.0, ang - cone);
    }
}
