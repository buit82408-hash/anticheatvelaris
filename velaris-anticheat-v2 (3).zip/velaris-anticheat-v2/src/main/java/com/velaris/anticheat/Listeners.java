package com.velaris.anticheat;

import com.velaris.anticheat.core.Aabb;
import com.velaris.anticheat.core.Check;
import com.velaris.anticheat.core.CartChecks;
import com.velaris.anticheat.core.ClickChecks;
import com.velaris.anticheat.core.CombatChecks;
import com.velaris.anticheat.core.History;
import com.velaris.anticheat.core.Look;
import com.velaris.anticheat.core.PlayerData;
import com.velaris.anticheat.core.Snapshot;
import com.velaris.anticheat.core.Verdict;
import java.util.List;
import org.bukkit.FluidCollisionMode;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Tag;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.block.Block;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.minecart.ExplosiveMinecart;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent.DamageCause;
import org.bukkit.event.entity.EntityPlaceEvent;
import org.bukkit.event.player.PlayerAnimationEvent;
import org.bukkit.event.player.PlayerAnimationType;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.util.BoundingBox;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;

/** Cầu nối sự kiện Paper → lõi kiểm tra. Mọi handler bọc try/catch: lỗi không bao giờ làm sập server. */
final class Listeners implements Listener {
    private final Engine eng;

    Listeners(Engine eng) { this.eng = eng; }

    // ------------------------------------------------------------------ vòng tick: lịch sử vị trí + kiểm tra theo thời gian

    void tick() {
        eng.advance();
        long t = eng.tick();
        long now = System.nanoTime();
        for (Player p : org.bukkit.Bukkit.getOnlinePlayers()) {
            try {
                PlayerData d = eng.data(p);
                d.history.put(snapshot(p, t));
                if (eng.bypass(p, d)) continue;
                eng.handle(p, d, CombatChecks.noSwingTick(d, eng.s(Check.NOSWING), now));
                double[] look = Look.dir(p.getLocation().getYaw(), p.getLocation().getPitch());
                eng.handle(p, d, CombatChecks.snapResolve(d, eng.s(Check.KILLAURA_SNAP), now, look));
                d.decay(t);
            } catch (Throwable ex) {
                eng.error("tick", ex);
            }
        }
    }

    private static Snapshot snapshot(Player p, long t) {
        Location l = p.getLocation();
        return new Snapshot(t, l.getX(), l.getY(), l.getZ(), l.getYaw(), l.getPitch(), p.getEyeHeight(), p.getWidth(), p.getHeight());
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onJoin(PlayerJoinEvent e) {
        try { eng.data(e.getPlayer()); } catch (Throwable t) { eng.error("join", t); }
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onQuit(PlayerQuitEvent e) {
        try { eng.remove(e.getPlayer().getUniqueId()); } catch (Throwable t) { eng.error("quit", t); }
    }

    // ------------------------------------------------------------------ vung tay (AutoClicker, NoSwing)

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onSwing(PlayerAnimationEvent e) {
        try {
            if (e.getAnimationType() != PlayerAnimationType.ARM_SWING) return;
            Player p = e.getPlayer();
            PlayerData d = eng.data(p);
            if (eng.bypass(p, d)) return;
            long now = System.nanoTime();
            CombatChecks.swing(d, eng.s(Check.NOSWING), now);

            // Đào khối tạo ra vung tay liên tục rất đều: không tính vào AutoClicker khi đang nhìn vào khối và không đánh ai gần đây.
            boolean recentHit = d.hasLastHit && now - d.lastHitNanos < 1_000_000_000L;
            if (!recentHit && p.getTargetBlockExact(5) != null) return;
            eng.handle(p, d, ClickChecks.cps(d, eng.s(Check.AUTOCLICKER_CPS), now));
            eng.handle(p, d, ClickChecks.pattern(d, eng.s(Check.AUTOCLICKER_PATTERN), eng.tick()));
        } catch (Throwable t) {
            eng.error("animation", t);
        }
    }

    // ------------------------------------------------------------------ đánh

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onHit(EntityDamageByEntityEvent e) {
        try {
            if (e.getCause() != DamageCause.ENTITY_ATTACK) return; // bỏ qua quét kiếm, tên, v.v.
            if (!(e.getDamager() instanceof Player att)) return;
            Entity victim = e.getEntity();
            if (victim == att || victim.getWorld() != att.getWorld()) return;
            PlayerData d = eng.data(att);
            if (eng.bypass(att, d)) return;
            GameMode gm = att.getGameMode();
            if (gm == GameMode.SPECTATOR) return;

            long tick = eng.tick();
            long now = System.nanoTime();
            Location eye = att.getEyeLocation();
            final double ex = eye.getX(), ey = eye.getY(), ez = eye.getZ();
            double[] look = Look.dir(eye.getYaw(), eye.getPitch());

            Snapshot attNow = snapshot(att, tick);
            Snapshot prev1 = d.history.at(tick - 1);
            Snapshot prev2 = d.history.at(tick - 2);
            double[] prevLook = prev1 == null ? null : prev1.look();
            double rot1 = prev1 == null ? -1 : com.velaris.anticheat.core.Look.angleDeg(look, prev1.look());
            double rot2 = prev1 == null || prev2 == null ? -1 : com.velaris.anticheat.core.Look.angleDeg(prev1.look(), prev2.look());

            BoundingBox vb = victim.getBoundingBox();
            Aabb nowBox = new Aabb(vb.getMinX(), vb.getMinY(), vb.getMinZ(), vb.getMaxX(), vb.getMaxY(), vb.getMaxZ());
            Player victimPlayer = victim instanceof Player vp ? vp : null;
            PlayerData vd = victimPlayer == null ? null : eng.peek(victimPlayer.getUniqueId());
            History vh = vd == null ? null : vd.history;

            int ping = att.getPing();
            int lag = CombatChecks.lagTicks(ping, (int) eng.s(Check.REACH).p("ping-cap-ms"));
            List<Aabb> boxes = CombatChecks.rewind(nowBox, vh, tick, lag);

            AttributeInstance ri = att.getAttribute(Attribute.ENTITY_INTERACTION_RANGE);
            double range = ri != null ? ri.getValue() : 3.0;
            if (gm == GameMode.CREATIVE) range = Math.max(range, 5.0);

            boolean cancel = false;
            Verdict v;

            v = CombatChecks.reach(d, eng.s(Check.REACH), range, ex, ey, ez, boxes, ping);
            eng.handle(att, d, v);
            cancel |= v.flagged();

            if (victimPlayer != null) {
                v = CombatChecks.hitbox(d, eng.s(Check.HITBOX), ex, ey, ez, look, rot1, rot2, boxes, range + 1.5);
                eng.handle(att, d, v);
                cancel |= v.flagged();
            }

            eng.handle(att, d, CombatChecks.angle(d, eng.s(Check.KILLAURA_ANGLE), ex, ey, ez, look, prevLook, boxes));

            double ux = nowBox.cx() - ex, uy = nowBox.cy() - ey, uz = nowBox.cz() - ez;
            double ul = Math.sqrt(ux * ux + uy * uy + uz * uz);
            if (ul > 1e-6) {
                eng.handle(att, d, CombatChecks.multi(d, eng.s(Check.KILLAURA_MULTI), victim.getEntityId(), ux / ul, uy / ul, uz / ul, now));
            }

            // xuyên khối: tia từ mắt tới điểm gần nhất của hitbox mục tiêu
            double[] near = nowBox.nearest(ex, ey, ez);
            double nx = near[0] - ex, ny = near[1] - ey, nz = near[2] - ez;
            double dist = Math.sqrt(nx * nx + ny * ny + nz * nz);
            if (dist >= 1e-6) {
                Vector dir = new Vector(nx / dist, ny / dist, nz / dist);
                RayTraceResult rt = att.getWorld().rayTraceBlocks(eye, dir, dist, FluidCollisionMode.NEVER, true);
                double blockDist = rt == null ? -1.0 : rt.getHitPosition().distance(eye.toVector());
                v = CombatChecks.wall(d, eng.s(Check.KILLAURA_WALL), blockDist, dist);
                eng.handle(att, d, v);
                cancel |= v.flagged();
            }

            eng.handle(att, d, CombatChecks.useItem(d, eng.s(Check.KILLAURA_ITEM), att.isHandRaised()));
            CombatChecks.snapStart(d, eng.s(Check.KILLAURA_SNAP), now, prevLook, look);
            CombatChecks.hit(d, eng.s(Check.NOSWING), now);

            if (victimPlayer != null) {
                int run = CombatChecks.onTargetRun(d.history, attNow, vh, nowBox, tick, lag,
                        eng.s(Check.TRIGGERBOT).p("expand"), 8);
                eng.handle(att, d, CombatChecks.trigger(d, eng.s(Check.TRIGGERBOT), now, run));
            }

            if (cancel && eng.cancelFlaggedHits) e.setCancelled(true);
        } catch (Throwable t) {
            eng.error("EntityDamageByEntityEvent", t);
        }
    }

    // ------------------------------------------------------------------ AutoCart (chỉ ĐẶT và CHÂM; bắn cung/tên không tính)

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onPlace(BlockPlaceEvent e) {
        try {
            Material m = e.getBlockPlaced().getType();
            if (Tag.RAILS.isTagged(m)) cart(e.getPlayer(), CartChecks.Event.RAIL);
            else if (m == Material.TNT) cart(e.getPlayer(), CartChecks.Event.TNT);
        } catch (Throwable t) {
            eng.error("BlockPlaceEvent", t);
        }
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onEntityPlace(EntityPlaceEvent e) {
        try {
            Player p = e.getPlayer();
            if (p != null && e.getEntity() instanceof ExplosiveMinecart) cart(p, CartChecks.Event.CART);
        } catch (Throwable t) {
            eng.error("EntityPlaceEvent", t);
        }
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onIgniteCart(PlayerInteractEntityEvent e) {
        try {
            if (e.getHand() != EquipmentSlot.HAND) return;
            if (!(e.getRightClicked() instanceof ExplosiveMinecart)) return;
            if (!isIgniter(e.getPlayer().getInventory().getItemInMainHand())) return;
            cart(e.getPlayer(), CartChecks.Event.IGNITE_CART);
        } catch (Throwable t) {
            eng.error("PlayerInteractEntityEvent", t);
        }
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onIgniteBlock(PlayerInteractEvent e) {
        try {
            if (e.getHand() != EquipmentSlot.HAND || e.getAction() != Action.RIGHT_CLICK_BLOCK) return;
            Block b = e.getClickedBlock();
            if (b == null || b.getType() != Material.TNT) return;
            if (!isIgniter(e.getItem())) return;
            cart(e.getPlayer(), CartChecks.Event.IGNITE_OTHER);
        } catch (Throwable t) {
            eng.error("PlayerInteractEvent", t);
        }
    }

    private static boolean isIgniter(ItemStack it) {
        return it != null && (it.getType() == Material.FLINT_AND_STEEL || it.getType() == Material.FIRE_CHARGE);
    }

    private void cart(Player p, CartChecks.Event ev) {
        PlayerData d = eng.data(p);
        if (eng.bypass(p, d)) return;
        for (Verdict v : CartChecks.on(d, ev, System.nanoTime(), eng.s(Check.AUTOCART_SEQUENCE), eng.s(Check.AUTOCART_RATE))) {
            eng.handle(p, d, v);
        }
    }
}
