package com.velaris.anticheat;

import com.velaris.anticheat.core.Check;
import com.velaris.anticheat.core.CheckSettings;
import com.velaris.anticheat.core.PlayerData;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import net.kyori.adventure.text.minimessage.tag.resolver.Placeholder;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

public final class VelarisAnticheat extends JavaPlugin implements CommandExecutor, TabCompleter {
    private Engine eng;

    @Override
    public void onEnable() {
        eng = new Engine(this);
        try {
            eng.load();
        } catch (Throwable t) {
            getLogger().severe("Không nạp được cấu hình: " + t);
            getServer().getPluginManager().disablePlugin(this);
            return;
        }
        Listeners l = new Listeners(eng);
        getServer().getPluginManager().registerEvents(l, this);
        getServer().getScheduler().runTaskTimer(this, l::tick, 1L, 1L);
        var cmd = getCommand("velaris");
        if (cmd != null) {
            cmd.setExecutor(this);
            cmd.setTabCompleter(this);
        }
        int on = 0;
        for (CheckSettings s : eng.checks.values()) if (s.enabled) on++;
        getLogger().info("Velaris_Anticheat v2 đã bật: " + on + "/" + Check.values().length + " check combat đang chạy, Discord "
                + (eng.discord != null ? "BẬT" : "tắt") + ".");
    }

    @Override
    public void onDisable() {
        getServer().getScheduler().cancelTasks(this);
        if (eng != null) eng.close();
    }

    private void say(CommandSender to, String key, net.kyori.adventure.text.minimessage.tag.resolver.TagResolver... r) {
        to.sendMessage(eng.alerts.parse(eng.alerts.msg(key), r));
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (eng == null) return true;
        String sub = args.length == 0 ? "status" : args[0].toLowerCase(Locale.ROOT);
        switch (sub) {
            case "alerts" -> {
                if (!(sender instanceof Player p)) { say(sender, "only-player"); return true; }
                say(sender, eng.toggleAlerts(p.getUniqueId()) ? "alerts-on" : "alerts-off");
            }
            case "reload" -> {
                try {
                    eng.load();
                    say(sender, "reloaded");
                } catch (Throwable t) {
                    sender.sendMessage("[Velaris] Lỗi khi nạp lại: " + t);
                }
            }
            case "vl" -> {
                Player t = args.length < 2 ? null : Bukkit.getPlayerExact(args[1]);
                PlayerData d = t == null ? null : eng.peek(t.getUniqueId());
                if (d == null) { say(sender, "no-player"); return true; }
                d.decay(eng.tick());
                say(sender, "vl-header", Placeholder.unparsed("player", t.getName()));
                boolean any = false;
                for (Check c : Check.values()) {
                    if (d.vl(c) < 0.05) continue;
                    any = true;
                    say(sender, "vl-line", Placeholder.unparsed("check", c.display()),
                            Placeholder.unparsed("vl", String.format(Locale.ROOT, "%.1f", d.vl(c))));
                }
                if (!any) say(sender, "vl-clean");
            }
            case "reset" -> {
                Player t = args.length < 2 ? null : Bukkit.getPlayerExact(args[1]);
                PlayerData d = t == null ? null : eng.peek(t.getUniqueId());
                if (d == null) { say(sender, "no-player"); return true; }
                for (Check c : Check.values()) d.resetVl(c);
                say(sender, "vl-reset", Placeholder.unparsed("player", t.getName()));
            }
            case "tp" -> {
                Player t = args.length < 2 ? null : Bukkit.getPlayerExact(args[1]);
                if (!(sender instanceof Player p)) { say(sender, "only-player"); return true; }
                if (t == null) { say(sender, "no-player"); return true; }
                p.teleport(t.getLocation());
            }
            case "webhook" -> {
                if (eng.discord == null) { say(sender, "webhook-off"); return true; }
                say(sender, "webhook-sending");
                eng.discord.test().thenAccept(ok -> Bukkit.getScheduler().runTask(this, () -> {
                    if (ok) say(sender, "webhook-ok");
                    else say(sender, "webhook-fail", Placeholder.unparsed("error", String.valueOf(eng.discord == null ? "" : eng.discord.lastError())));
                }));
            }
            case "checks" -> {
                say(sender, "checks-header");
                for (Check c : Check.values()) {
                    CheckSettings s = eng.s(c);
                    say(sender, s.enabled ? "check-on" : "check-off", Placeholder.unparsed("check", c.display()),
                            Placeholder.unparsed("file", "checks/" + c.file()));
                }
            }
            default -> say(sender, "status", Placeholder.unparsed("version", getPluginMeta().getVersion()),
                    Placeholder.unparsed("tps", String.format(Locale.ROOT, "%.1f", eng.tps())),
                    Placeholder.unparsed("discord", eng.discord != null ? "bật" : "tắt"));
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> out = new ArrayList<>();
        if (args.length == 1) {
            for (String s : List.of("status", "alerts", "checks", "vl", "reset", "tp", "webhook", "reload"))
                if (s.startsWith(args[0].toLowerCase(Locale.ROOT))) out.add(s);
        } else if (args.length == 2 && List.of("vl", "reset", "tp").contains(args[0].toLowerCase(Locale.ROOT))) {
            for (Player p : Bukkit.getOnlinePlayers())
                if (p.getName().toLowerCase(Locale.ROOT).startsWith(args[1].toLowerCase(Locale.ROOT))) out.add(p.getName());
        } else if (args.length == 2 && args[0].equalsIgnoreCase("webhook")) {
            out.add("test");
        }
        return out;
    }
}
