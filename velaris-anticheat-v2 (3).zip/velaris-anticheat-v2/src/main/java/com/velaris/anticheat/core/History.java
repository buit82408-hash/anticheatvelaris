package com.velaris.anticheat.core;

/** Vòng đệm 64 tick (~3.2 giây) lịch sử trạng thái của một thực thể. */
public final class History {
    private final Snapshot[] ring = new Snapshot[64];

    public void put(Snapshot s) { ring[(int) (s.tick() & 63L)] = s; }

    /** Trạng thái tại đúng tick đó, hoặc null nếu không có. */
    public Snapshot at(long tick) {
        if (tick < 0) return null;
        Snapshot s = ring[(int) (tick & 63L)];
        return s != null && s.tick() == tick ? s : null;
    }
}
