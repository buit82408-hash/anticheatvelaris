package com.velaris.anticheat.core;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentLinkedDeque;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Gửi cảnh báo qua webhook Discord. Không phụ thuộc thư viện ngoài.
 *  - Chạy hoàn toàn bất đồng bộ (không bao giờ chặn luồng chính của server).
 *  - Gom tối đa 10 embed mỗi request, gửi định kỳ.
 *  - Tôn trọng rate limit (HTTP 429 + retry_after), thử lại tối đa 3 lần, hàng đợi có giới hạn.
 *  - allowed_mentions rỗng: tên người chơi không thể gây ping @everyone.
 */
public final class DiscordWebhook implements AutoCloseable {

    public record Field(String name, String value, boolean inline) {}

    public record Embed(String title, String description, int color, List<Field> fields,
                        String thumbnail, String footer, String timestamp) {}

    private static final Pattern RETRY_AFTER = Pattern.compile("\"retry_after\"\\s*:\\s*([0-9]+(?:\\.[0-9]+)?)");

    private final URI uri;
    private final String username;
    private final String avatarUrl;
    private final Consumer<String> log;
    private final int maxQueue;
    private final HttpClient http = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(5)).build();
    private final ScheduledExecutorService ex = Executors.newSingleThreadScheduledExecutor(r -> {
        Thread t = new Thread(r, "Velaris-Discord");
        t.setDaemon(true);
        return t;
    });
    private final ConcurrentLinkedDeque<Embed> queue = new ConcurrentLinkedDeque<>();

    private volatile long blockedUntilNanos;
    private int failures;
    private volatile long lastRetryHintMs;
    private volatile String lastErrorSummary = "";

    public DiscordWebhook(String url, String username, String avatarUrl, long flushMs, int maxQueue,
                          boolean allowAnyHost, Consumer<String> log) {
        if (!validUrl(url, allowAnyHost)) throw new IllegalArgumentException("URL webhook không hợp lệ");
        this.uri = URI.create(url);
        this.username = username == null ? "" : username;
        this.avatarUrl = avatarUrl == null ? "" : avatarUrl;
        this.maxQueue = Math.max(10, maxQueue);
        this.log = log == null ? s -> {} : log;
        long period = Math.max(500L, flushMs);
        ex.scheduleWithFixedDelay(this::flushSafe, period, period, TimeUnit.MILLISECONDS);
    }

    /** Chỉ chấp nhận https://discord.com|discordapp.com/api/webhooks/... (trừ khi allowAny, dùng cho kiểm thử). */
    public static boolean validUrl(String url, boolean allowAny) {
        try {
            URI u = URI.create(url == null ? "" : url.trim());
            String scheme = u.getScheme();
            String host = u.getHost();
            if (scheme == null || host == null) return false;
            if (allowAny) return scheme.equalsIgnoreCase("https") || scheme.equalsIgnoreCase("http");
            if (!scheme.equalsIgnoreCase("https")) return false;
            boolean discordHost = host.equals("discord.com") || host.equals("discordapp.com")
                    || host.endsWith(".discord.com") || host.endsWith(".discordapp.com");
            return discordHost && u.getPath() != null && u.getPath().startsWith("/api/webhooks/");
        } catch (RuntimeException e) {
            return false;
        }
    }

    public void enqueue(Embed e) {
        queue.addLast(e);
        while (queue.size() > maxQueue) queue.pollFirst(); // quá tải: bỏ cái cũ nhất
    }

    public int pending() { return queue.size(); }

    /** Gửi thử một embed, trả về true nếu Discord nhận (2xx). */
    public CompletableFuture<Boolean> sendTest(Embed e) {
        CompletableFuture<Boolean> f = new CompletableFuture<>();
        ex.execute(() -> {
            try {
                int st = post(buildJson(List.of(e)));
                f.complete(st >= 200 && st < 300);
            } catch (Exception err) {
                lastErrorSummary = String.valueOf(err.getMessage());
                f.complete(false);
            }
        });
        return f;
    }

    public String lastError() { return lastErrorSummary; }

    // ------------------------------------------------------------------ nội bộ

    private void flushSafe() {
        try {
            flush();
        } catch (Throwable t) {
            lastErrorSummary = String.valueOf(t);
        }
    }

    private void flush() {
        if (System.nanoTime() < blockedUntilNanos) return;
        List<Embed> batch = new ArrayList<>(10);
        Embed e;
        while (batch.size() < 10 && (e = queue.pollFirst()) != null) batch.add(e);
        if (batch.isEmpty()) return;
        int status;
        try {
            status = post(buildJson(batch));
        } catch (Exception err) {
            lastErrorSummary = String.valueOf(err.getMessage());
            handleFailure(batch, "lỗi mạng: " + err.getMessage());
            return;
        }
        if (status >= 200 && status < 300) {
            failures = 0;
            return;
        }
        if (status == 429) {
            long waitMs = Math.max(100L, Math.min(60_000L, lastRetryHintMs));
            blockedUntilNanos = System.nanoTime() + waitMs * 1_000_000L;
            requeue(batch);
            return;
        }
        handleFailure(batch, "HTTP " + status);
    }

    private void handleFailure(List<Embed> batch, String why) {
        failures++;
        lastErrorSummary = why;
        if (failures < 3) {
            requeue(batch);
            blockedUntilNanos = System.nanoTime() + 2_000_000_000L;
        } else {
            failures = 0;
            log.accept("Không gửi được " + batch.size() + " cảnh báo tới Discord (" + why + "), đã bỏ qua.");
        }
    }

    private void requeue(List<Embed> batch) {
        for (int i = batch.size() - 1; i >= 0; i--) queue.addFirst(batch.get(i));
        while (queue.size() > maxQueue) queue.pollLast();
    }

    private int post(String json) throws Exception {
        HttpRequest req = HttpRequest.newBuilder(uri)
                .timeout(Duration.ofSeconds(8))
                .header("Content-Type", "application/json; charset=utf-8")
                .header("User-Agent", "VelarisAnticheat/2.0")
                .POST(HttpRequest.BodyPublishers.ofString(json, StandardCharsets.UTF_8))
                .build();
        HttpResponse<String> r = http.send(req, HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8));
        if (r.statusCode() == 429) {
            long ms = 2000L;
            Matcher m = RETRY_AFTER.matcher(r.body() == null ? "" : r.body());
            if (m.find()) {
                ms = (long) (Double.parseDouble(m.group(1)) * 1000.0);
            } else {
                String h = r.headers().firstValue("Retry-After").orElse("");
                try { ms = (long) (Double.parseDouble(h.trim()) * 1000.0); } catch (NumberFormatException ignored) { /* mặc định */ }
            }
            lastRetryHintMs = ms;
        }
        return r.statusCode();
    }

    // ------------------------------------------------------------------ JSON

    String buildJson(List<Embed> embeds) {
        StringBuilder sb = new StringBuilder(512);
        sb.append('{');
        if (!username.isBlank()) sb.append("\"username\":").append(str(username, 80)).append(',');
        if (!avatarUrl.isBlank()) sb.append("\"avatar_url\":").append(str(avatarUrl, 500)).append(',');
        sb.append("\"allowed_mentions\":{\"parse\":[]},\"embeds\":[");
        for (int i = 0; i < embeds.size(); i++) {
            if (i > 0) sb.append(',');
            embed(sb, embeds.get(i));
        }
        sb.append("]}");
        return sb.toString();
    }

    private static void embed(StringBuilder sb, Embed e) {
        sb.append('{');
        sb.append("\"title\":").append(str(e.title(), 256));
        if (e.description() != null && !e.description().isBlank()) sb.append(",\"description\":").append(str(e.description(), 4000));
        sb.append(",\"color\":").append(Math.max(0, Math.min(0xFFFFFF, e.color())));
        if (e.timestamp() != null && !e.timestamp().isBlank()) sb.append(",\"timestamp\":").append(str(e.timestamp(), 40));
        if (e.footer() != null && !e.footer().isBlank()) sb.append(",\"footer\":{\"text\":").append(str(e.footer(), 2000)).append('}');
        if (e.thumbnail() != null && !e.thumbnail().isBlank()) sb.append(",\"thumbnail\":{\"url\":").append(str(e.thumbnail(), 500)).append('}');
        if (e.fields() != null && !e.fields().isEmpty()) {
            sb.append(",\"fields\":[");
            int n = 0;
            for (Field f : e.fields()) {
                if (n >= 25) break;
                if (n++ > 0) sb.append(',');
                String v = f.value() == null || f.value().isBlank() ? "-" : f.value();
                sb.append("{\"name\":").append(str(f.name() == null || f.name().isBlank() ? "-" : f.name(), 256))
                        .append(",\"value\":").append(str(v, 1024))
                        .append(",\"inline\":").append(f.inline()).append('}');
            }
            sb.append(']');
        }
        sb.append('}');
    }

    /** Chuỗi JSON đã thoát ký tự và cắt độ dài (theo giới hạn của Discord). */
    static String str(String s, int max) {
        if (s == null) s = "";
        if (s.length() > max) s = s.substring(0, Math.max(0, max - 1)) + "…";
        StringBuilder sb = new StringBuilder(s.length() + 2);
        sb.append('"');
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            switch (c) {
                case '"' -> sb.append("\\\"");
                case '\\' -> sb.append("\\\\");
                case '\n' -> sb.append("\\n");
                case '\r' -> sb.append("\\r");
                case '\t' -> sb.append("\\t");
                default -> {
                    if (c < 0x20) sb.append(String.format("\\u%04x", (int) c));
                    else sb.append(c);
                }
            }
        }
        return sb.append('"').toString();
    }

    @Override
    public void close() {
        ex.shutdownNow();
    }
}
