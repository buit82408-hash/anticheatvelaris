package com.velaris.anticheat.core;

/** Hộp va chạm trục song song. */
public record Aabb(double minX, double minY, double minZ, double maxX, double maxY, double maxZ) {

    public static Aabb ofFeet(double x, double y, double z, double width, double height) {
        double hw = width / 2.0;
        return new Aabb(x - hw, y, z - hw, x + hw, y + height, z + hw);
    }

    public Aabb inflate(double e) {
        return new Aabb(minX - e, minY - e, minZ - e, maxX + e, maxY + e, maxZ + e);
    }

    public double cx() { return (minX + maxX) / 2.0; }
    public double cy() { return (minY + maxY) / 2.0; }
    public double cz() { return (minZ + maxZ) / 2.0; }

    /** Bán kính hình cầu bao hộp. */
    public double radius() {
        double dx = maxX - minX, dy = maxY - minY, dz = maxZ - minZ;
        return 0.5 * Math.sqrt(dx * dx + dy * dy + dz * dz);
    }

    /** Khoảng cách từ điểm tới điểm gần nhất của hộp (0 nếu nằm trong). */
    public double distanceTo(double x, double y, double z) {
        double dx = x - clamp(x, minX, maxX);
        double dy = y - clamp(y, minY, maxY);
        double dz = z - clamp(z, minZ, maxZ);
        return Math.sqrt(dx * dx + dy * dy + dz * dz);
    }

    /** Điểm gần nhất của hộp tới (x,y,z). */
    public double[] nearest(double x, double y, double z) {
        return new double[] {clamp(x, minX, maxX), clamp(y, minY, maxY), clamp(z, minZ, maxZ)};
    }

    /** Tia (gốc o, hướng d đã chuẩn hoá) có cắt hộp trong khoảng [0, maxDist] không. */
    public boolean rayHits(double ox, double oy, double oz, double dx, double dy, double dz, double maxDist) {
        double tmin = 0.0, tmax = maxDist;
        double[] o = {ox, oy, oz};
        double[] d = {dx, dy, dz};
        double[] lo = {minX, minY, minZ};
        double[] hi = {maxX, maxY, maxZ};
        for (int i = 0; i < 3; i++) {
            if (Math.abs(d[i]) < 1e-12) {
                if (o[i] < lo[i] || o[i] > hi[i]) return false;
            } else {
                double t1 = (lo[i] - o[i]) / d[i];
                double t2 = (hi[i] - o[i]) / d[i];
                if (t1 > t2) { double t = t1; t1 = t2; t2 = t; }
                tmin = Math.max(tmin, t1);
                tmax = Math.min(tmax, t2);
                if (tmin > tmax) return false;
            }
        }
        return true;
    }

    private static double clamp(double v, double lo, double hi) { return Math.max(lo, Math.min(hi, v)); }
}
