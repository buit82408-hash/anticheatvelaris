package com.velaris.anticheat.core;

/** Nguồn cấu hình trừu tượng (YAML của Bukkit khi chạy thật, map khi kiểm thử). Khoá dạng "a.b.c". */
public interface Source {
    Object get(String path);
}
