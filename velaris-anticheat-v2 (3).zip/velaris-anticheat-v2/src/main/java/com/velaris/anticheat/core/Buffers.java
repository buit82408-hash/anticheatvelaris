package com.velaris.anticheat.core;

import java.util.function.Supplier;

/** Cơ chế bộ đệm chung: vi phạm cộng điểm, hợp lệ trừ điểm; chỉ flag khi vượt ngưỡng. */
final class Buffers {
    private Buffers() {}

    static Verdict push(PlayerData d, Check c, CheckSettings s, boolean violation, double inc, double decay,
                        double limit, Supplier<String> detail) {
        int i = c.ordinal();
        if (violation) {
            d.buf[i] += inc;
            if (d.buf[i] >= limit) {
                d.buf[i] = limit / 2.0;
                return Verdict.flag(c, s.weight, detail.get());
            }
        } else {
            d.buf[i] = Math.max(0.0, d.buf[i] - decay);
        }
        return Verdict.NONE;
    }
}
