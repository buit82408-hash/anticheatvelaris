package com.velaris.anticheat.core;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;

/** Cấu hình riêng của từng check (đọc từ file YAML riêng của check đó). */
public final class CheckSettings {
    public final Check check;
    public boolean enabled = true;
    public boolean alert = true;
    public boolean discord = true;
    public double weight = 1.0;
    public int punishVl = 0;
    public List<String> commands = new ArrayList<>();
    public final Map<String, Double> params = new LinkedHashMap<>();

    private CheckSettings(Check check) { this.check = check; }

    public double p(String key) {
        Double v = params.get(key);
        if (v == null) throw new IllegalStateException("Thiếu tham số " + key + " của " + check);
        return v;
    }

    public static CheckSettings defaults(Check c) {
        CheckSettings s = new CheckSettings(c);
        for (Check.Param p : c.params()) s.params.put(p.key(), p.def());
        return s;
    }

    /**
     * Nạp từ YAML. Giá trị sai kiểu hoặc âm bị bỏ qua (dùng mặc định) và báo qua {@code warn}.
     * @param prefix "" hoặc "tên-section."
     */
    public static CheckSettings load(Source src, String prefix, Check c, Consumer<String> warn) {
        CheckSettings s = defaults(c);
        s.enabled = bool(src, prefix + "enabled", s.enabled, c, warn);
        s.alert = bool(src, prefix + "alert", s.alert, c, warn);
        s.discord = bool(src, prefix + "discord", s.discord, c, warn);

        Object w = src.get(prefix + "vl-weight");
        if (w instanceof Number n && n.doubleValue() >= 0 && Double.isFinite(n.doubleValue())) s.weight = n.doubleValue();
        else if (w != null) warn.accept(c.display() + ": vl-weight không hợp lệ, dùng mặc định " + s.weight);

        Object pv = src.get(prefix + "punish.vl");
        if (pv instanceof Number n && n.intValue() >= 0) s.punishVl = n.intValue();
        else if (pv != null) warn.accept(c.display() + ": punish.vl không hợp lệ, dùng mặc định 0");

        Object cmds = src.get(prefix + "punish.commands");
        if (cmds instanceof List<?> l) {
            List<String> out = new ArrayList<>();
            for (Object o : l) if (o != null && !o.toString().isBlank()) out.add(o.toString());
            s.commands = out;
        } else if (cmds != null) {
            warn.accept(c.display() + ": punish.commands phải là danh sách");
        }

        for (Check.Param p : c.params()) {
            Object o = src.get(prefix + "settings." + p.key());
            if (o instanceof Number n && Double.isFinite(n.doubleValue()) && n.doubleValue() >= 0) {
                s.params.put(p.key(), n.doubleValue());
            } else if (o != null) {
                warn.accept(c.display() + ": settings." + p.key() + " không hợp lệ (" + o + "), dùng mặc định " + p.def());
            }
        }
        return s;
    }

    private static boolean bool(Source src, String path, boolean def, Check c, Consumer<String> warn) {
        Object v = src.get(path);
        if (v instanceof Boolean b) return b;
        if (v != null) warn.accept(c.display() + ": " + path + " phải là true/false, dùng mặc định " + def);
        return def;
    }
}
