package com.velaris.anticheat.core;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Sinh nội dung các file YAML mặc định của từng check (có chú thích tiếng Việt). */
public final class DefaultFiles {
    private DefaultFiles() {}

    public static List<String> files() {
        List<String> out = new ArrayList<>();
        for (Check c : Check.values()) if (!out.contains(c.file())) out.add(c.file());
        return out;
    }

    public static String render(String file) {
        StringBuilder sb = new StringBuilder();
        sb.append("# Velaris_Anticheat — ").append(file).append('\n');
        sb.append("# enabled     : bật/tắt check\n");
        sb.append("# alert       : gửi cảnh báo trong game/console\n");
        sb.append("# discord     : gửi cảnh báo qua webhook Discord (cần bật trong discord.yml)\n");
        sb.append("# vl-weight   : số VL cộng mỗi lần flag\n");
        sb.append("# punish      : khi VL >= punish.vl (>0) thì chạy các lệnh (%player% = tên người chơi) rồi đặt lại VL\n");
        sb.append("# settings    : ngưỡng riêng của check (giá trị mặc định thiên về ít báo nhầm)\n\n");
        for (Check c : Check.values()) {
            if (!c.file().equals(file)) continue;
            String ind = "";
            if (c.section() != null) {
                sb.append(c.section()).append(":\n");
                ind = "  ";
            }
            sb.append(ind).append("enabled: true\n");
            sb.append(ind).append("alert: true\n");
            sb.append(ind).append("discord: true\n");
            sb.append(ind).append("vl-weight: 1.0\n");
            sb.append(ind).append("punish:\n");
            sb.append(ind).append("  vl: 0\n");
            sb.append(ind).append("  commands: []\n");
            sb.append(ind).append("settings:\n");
            for (Check.Param p : c.params()) {
                sb.append(ind).append("  # ").append(p.comment()).append('\n');
                sb.append(ind).append("  ").append(p.key()).append(": ").append(fmt(p.def())).append('\n');
            }
            sb.append('\n');
        }
        return sb.toString();
    }

    private static String fmt(double v) {
        if (v == Math.rint(v) && Math.abs(v) < 1e9) return String.format(Locale.ROOT, "%.1f", v);
        return Double.toString(v);
    }
}
