package com.velaris.anticheat.core;

import java.util.ArrayList;
import java.util.List;

/**
 * Danh sách check. Mỗi check thuộc một file YAML riêng trong thư mục checks/ (và một "section" nếu file chứa nhiều check).
 * Giá trị mặc định + chú thích ở đây là nguồn duy nhất để sinh file YAML, nên file và mã không bao giờ lệch nhau.
 */
public enum Check {
    REACH("Reach", "reach.yml", null,
            p("extra", 0.12, "Dung sai ngoài tầm đánh (block). Tầm đánh lấy từ attribute (3.0 sinh tồn, 5.0 creative)."),
            p("buffer", 3.0, "Số cú đánh vượt tầm (đã bù ping bằng lịch sử vị trí) trước khi flag."),
            p("ping-cap-ms", 300.0, "Ping tối đa dùng để tua lại vị trí mục tiêu.")),

    HITBOX("Hitbox", "hitbox.yml", null,
            p("expand", 0.12, "Phần hitbox nới thêm cho phép (block) để bù sai số xoay đầu/nội suy."),
            p("buffer", 4.0, "Số cú đánh trượt hitbox liên tiếp trước khi flag."),
            p("max-rotation", 2.0, "Chỉ kiểm tra khi góc xoay giữa các tick nhỏ hơn mức này (độ); xoay nhanh (flick) thì bỏ qua để tránh báo nhầm.")),

    KILLAURA_ANGLE("KillAura-Angle", "killaura.yml", "angle",
            p("max-angle", 40.0, "Góc lệch tối đa (độ) giữa hướng nhìn và mục tiêu, đã trừ hình cầu bao hitbox."),
            p("buffer", 4.0, "Số cú đánh lệch hướng trước khi flag.")),

    KILLAURA_MULTI("KillAura-Multi", "killaura.yml", "multi",
            p("min-angle", 60.0, "Hai mục tiêu cách nhau quá góc này (độ) mà bị đánh gần như đồng thời."),
            p("window-ms", 60.0, "Khoảng thời gian coi là đồng thời (ms)."),
            p("buffer", 3.0, "Số lần xảy ra trước khi flag.")),

    KILLAURA_WALL("KillAura-Wall", "killaura.yml", "wall",
            p("tolerance", 0.25, "Khối chắn phải nằm gần người đánh hơn mục tiêu ít nhất ngần này (block)."),
            p("min-distance", 1.0, "Bỏ qua khi mục tiêu gần hơn mức này (block)."),
            p("buffer", 5.0, "Số cú đánh xuyên khối trước khi flag.")),

    KILLAURA_SNAP("KillAura-Snap", "killaura.yml", "snap",
            p("min-snap", 45.0, "Góc xoay đột ngột (độ) tại cú đánh để bắt đầu theo dõi."),
            p("return-within", 8.0, "Nếu sau đó hướng nhìn quay về trong ngần này (độ) so với trước cú đánh thì nghi vấn (silent rotation)."),
            p("window-ms", 150.0, "Thời gian theo dõi sau cú đánh (ms)."),
            p("buffer", 2.0, "Số lần trước khi flag.")),

    KILLAURA_ITEM("KillAura-UseItem", "killaura.yml", "use-item",
            p("buffer", 3.0, "Số cú đánh khi đang giơ khiên/ăn/kéo cung trước khi flag.")),

    NOSWING("NoSwing", "killaura.yml", "no-swing",
            p("wait-ms", 250.0, "Thời gian chờ cú vung tay sau cú đánh (ms)."),
            p("buffer", 4.0, "Số cú đánh không vung tay trước khi flag. Plugin kỹ năng gây sát thương bằng API có thể gây báo nhầm.")),

    TRIGGERBOT("TriggerBot", "triggerbot.yml", null,
            p("min-gap-ms", 500.0, "Chỉ tính các cú đánh cách cú click trước ít nhất ngần này (ms), loại trừ spam click."),
            p("instant-ticks", 2.0, "Tâm ngắm chỉ nằm trên mục tiêu ≤ số tick này trước khi đánh được coi là 'phản xạ tức thì'."),
            p("window", 12.0, "Số cú đánh gần nhất (đủ điều kiện) dùng để thống kê (tối đa 32)."),
            p("min-instant", 10.0, "Cần ít nhất bấy nhiêu cú 'tức thì' trong cửa sổ."),
            p("ratio", 0.85, "Tỉ lệ 'tức thì' tối thiểu trong cửa sổ."),
            p("expand", 0.12, "Nới hitbox khi dựng lại thời điểm tâm ngắm vào mục tiêu (block).")),

    AUTOCLICKER_CPS("AutoClicker-CPS", "autoclicker.yml", "cps",
            p("max-cps", 23.0, "CPS tối đa trong cửa sổ 1 giây."),
            p("buffer", 12.0, "Số lần đánh giá (4 lần/giây) vượt ngưỡng trước khi flag, ~3 giây liên tục.")),

    AUTOCLICKER_PATTERN("AutoClicker-Pattern", "autoclicker.yml", "pattern",
            p("min-clicks", 50.0, "Số click liên tục dùng để phân tích (tối đa 120)."),
            p("min-cps", 7.0, "Chỉ phân tích khi CPS trung bình ≥ mức này."),
            p("max-std", 0.25, "Độ lệch chuẩn khoảng cách giữa các click (tính bằng tick) nhỏ hơn mức này là quá đều."),
            p("buffer", 2.0, "Số cửa sổ liên tiếp quá đều trước khi flag.")),

    AUTOCART_SEQUENCE("AutoCart-Sequence", "autocart.yml", "sequence",
            p("rail-to-cart-ms", 60.0, "Đặt ray → đặt xe TNT nhanh hơn mức này (ms) là bất thường."),
            p("cart-to-ignite-ms", 60.0, "Đặt xe TNT → châm lửa (bật lửa/lửa) nhanh hơn mức này (ms) là bất thường."),
            p("total-ms", 150.0, "Cả chuỗi ray → châm lửa nhanh hơn mức này (ms)."),
            p("buffer", 3.0, "Điểm tích luỹ trước khi flag (chuỗi rất nhanh = 2 điểm).")),

    AUTOCART_RATE("AutoCart-Rate", "autocart.yml", "rate",
            p("rail-per-sec", 12.0, "Số ray đặt tối đa mỗi giây."),
            p("tnt-per-sec", 10.0, "Số TNT đặt tối đa mỗi giây."),
            p("cart-per-sec", 4.0, "Số xe TNT đặt tối đa mỗi giây."),
            p("ignite-per-sec", 10.0, "Số lần châm lửa tối đa mỗi giây."),
            p("buffer", 3.0, "Số lần vượt trước khi flag."));

    /** Một tham số có giá trị mặc định và chú thích. */
    public record Param(String key, double def, String comment) {}

    private final String display;
    private final String file;
    private final String section;
    private final List<Param> params;

    Check(String display, String file, String section, Param... params) {
        this.display = display;
        this.file = file;
        this.section = section;
        List<Param> l = new ArrayList<>();
        for (Param p : params) l.add(p);
        this.params = List.copyOf(l);
    }

    private static Param p(String key, double def, String comment) { return new Param(key, def, comment); }

    public String display() { return display; }
    public String file() { return file; }
    /** null nếu check là nội dung gốc của file. */
    public String section() { return section; }
    public List<Param> params() { return params; }
}
