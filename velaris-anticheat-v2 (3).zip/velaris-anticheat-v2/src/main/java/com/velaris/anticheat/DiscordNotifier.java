package com.velaris.anticheat;

import com.velaris.anticheat.core.Check;
import com.velaris.anticheat.core.DiscordWebhook;
import com.velaris.anticheat.core.DiscordWebhook.Embed;
import com.velaris.anticheat.core.DiscordWebhook.Field;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.CompletableFuture;
import org.bukkit.Location;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

/** Dựng embed Discord từ sự kiện flag. Việc gửi do {@link DiscordWebhook} xử lý bất đồng bộ. */
final class DiscordNotifier implements AutoCloseable {
    private final DiscordWebhook hook;
    private final String serverName;
    private final String headUrl;
    private final boolean sendPunish;

    private DiscordNotifier(DiscordWebhook hook, String serverName, String headUrl, boolean sendPunish) {
        this.hook = hook;
        this.serverName = serverName;
        this.headUrl = headUrl;
        this.sendPunish = sendPunish;
    }

    /** @return null nếu tắt hoặc URL không hợp lệ (đã báo trong console). */
    static DiscordNotifier create(JavaPlugin plugin, YamlConfiguration c, Engine eng) {
        if (!c.getBoolean("enabled", false)) return null;
        String url = c.getString("webhook-url", "");
        if (url == null || url.isBlank() || url.contains("PASTE")) {
            plugin.getLogger().warning("discord.yml: enabled=true nhưng chưa điền webhook-url.");
            return null;
        }
        if (!DiscordWebhook.validUrl(url, false)) {
            plugin.getLogger().warning("discord.yml: webhook-url không hợp lệ (phải là https://discord.com/api/webhooks/...).");
            return null;
        }
        DiscordWebhook hook = new DiscordWebhook(url, c.getString("username", "Velaris Anticheat"), c.getString("avatar-url", ""),
                Math.max(500L, c.getLong("flush-ms", 1500)), c.getInt("max-queue", 200), false,
                s -> plugin.getLogger().warning("[Discord] " + s));
        return new DiscordNotifier(hook, c.getString("server-name", "Server"), c.getString("head-url", ""), c.getBoolean("notify-punish", true));
    }

    private String head(Player p) {
        return headUrl == null || headUrl.isBlank() ? "" : headUrl.replace("<uuid>", p.getUniqueId().toString()).replace("<name>", p.getName());
    }

    void flag(Player p, Check check, double vl, String detail) {
        Location l = p.getLocation();
        List<Field> f = new ArrayList<>();
        f.add(new Field("Người chơi", p.getName(), true));
        f.add(new Field("Check", check.display(), true));
        f.add(new Field("VL", String.format(Locale.ROOT, "%.1f %s", vl, Alerts.bar(vl, 20.0)), true));
        f.add(new Field("Ping", p.getPing() + " ms", true));
        f.add(new Field("Thế giới", l.getWorld() == null ? "?" : l.getWorld().getName(), true));
        f.add(new Field("Vị trí", String.format(Locale.ROOT, "%.0f, %.0f, %.0f", l.getX(), l.getY(), l.getZ()), true));
        hook.enqueue(new Embed("🚨 " + p.getName() + " bị flag " + check.display(),
                "```" + detail.replace("```", "'''") + "```",
                Alerts.severityRgb(vl), f, head(p), serverName + " • Velaris Anticheat", Instant.now().toString()));
    }

    void punish(Player p, Check check, double vl, List<String> commands) {
        if (!sendPunish) return;
        List<Field> f = new ArrayList<>();
        f.add(new Field("Người chơi", p.getName(), true));
        f.add(new Field("Check", check.display(), true));
        f.add(new Field("VL", String.format(Locale.ROOT, "%.1f", vl), true));
        f.add(new Field("Lệnh", commands.isEmpty() ? "(không có)" : "```" + String.join("\n", commands) + "```", false));
        hook.enqueue(new Embed("⛔ Đã xử phạt " + p.getName(), check.display() + " vượt ngưỡng VL.", 0xDC2626, f, head(p),
                serverName + " • Velaris Anticheat", Instant.now().toString()));
    }

    CompletableFuture<Boolean> test() {
        return hook.sendTest(new Embed("✅ Kết nối webhook thành công", "Velaris Anticheat đã liên kết với kênh này.", 0x6366F1,
                List.of(new Field("Server", serverName, true)), "", serverName + " • Velaris Anticheat", Instant.now().toString()));
    }

    String lastError() { return hook.lastError(); }

    @Override
    public void close() { hook.close(); }
}
