package com.velaris.anticheat.core;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.UUID;

/** Dữ liệu theo từng người chơi. Chỉ dùng trên luồng chính của server. */
public final class PlayerData {
    public final UUID id;
    public final History history = new History();

    // ---- bộ đệm & VL
    final double[] buf = new double[Check.values().length];
    private final double[] vl = new double[Check.values().length];
    private long lastDecayTick = -1;
    public final long[] lastAlertNanos = new long[Check.values().length];
    public final long[] lastDiscordNanos = new long[Check.values().length];

    // ---- bypass (cache quyền)
    public boolean bypass;
    public long bypassCheckedTick = Long.MIN_VALUE;

    // ---- vung tay / NoSwing / TriggerBot
    public boolean hasSwing;
    public long lastSwingNanos;
    boolean hasPendingHit;
    long pendingHitNanos;

    // ---- CPS & mẫu click
    final Deque<Long> clicks = new ArrayDeque<>();
    long lastEvalNanos;
    boolean evalInit;
    final int[] gaps = new int[128];
    int gapN;
    long lastClickTick;
    boolean hasLastClickTick;

    // ---- đa mục tiêu
    public boolean hasLastHit;
    int lastHitId;
    public long lastHitNanos;
    double lastDx, lastDy, lastDz;

    // ---- snap
    boolean snapPending;
    long snapNanos;
    double[] snapLook;

    // ---- trigger bot
    final boolean[] trig = new boolean[32];
    int trigN, trigIdx;

    // ---- AutoCart
    boolean hasRail, hasCart;
    long lastRailNanos, lastCartNanos;
    final Deque<Long> railTimes = new ArrayDeque<>();
    final Deque<Long> tntTimes = new ArrayDeque<>();
    final Deque<Long> cartTimes = new ArrayDeque<>();
    final Deque<Long> igniteTimes = new ArrayDeque<>();

    public PlayerData(UUID id) { this.id = id; }

    public double vl(Check c) { return vl[c.ordinal()]; }

    public double addVl(Check c, double w, long tick) {
        decay(tick);
        return vl[c.ordinal()] += w;
    }

    public void resetVl(Check c) {
        vl[c.ordinal()] = 0.0;
    }

    /** VL giảm 1 điểm mỗi 60 giây (1200 tick). */
    public void decay(long tick) {
        if (lastDecayTick < 0) { lastDecayTick = tick; return; }
        long dt = tick - lastDecayTick;
        if (dt < 200) return;
        double d = dt / 1200.0;
        for (int i = 0; i < vl.length; i++) vl[i] = Math.max(0.0, vl[i] - d);
        lastDecayTick = tick;
    }

    public double buffer(Check c) { return buf[c.ordinal()]; }
}
