package com.velaris.anticheat.core;

/** Kết quả một lần kiểm tra. Chỉ {@code flagged} khi bộ đệm vượt ngưỡng, không flag theo từng sự kiện lẻ. */
public record Verdict(Check check, boolean flagged, double weight, String detail) {
    public static final Verdict NONE = new Verdict(null, false, 0.0, "");

    public static Verdict flag(Check check, double weight, String detail) {
        return new Verdict(check, true, weight, detail);
    }
}
