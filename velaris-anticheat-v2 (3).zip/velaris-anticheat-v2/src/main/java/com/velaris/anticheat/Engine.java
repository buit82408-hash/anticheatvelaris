package com.velaris.anticheat;

import com.velaris.anticheat.core.Check;
import com.velaris.anticheat.core.CheckSettings;
import com.velaris.anticheat.core.DefaultFiles;
import com.velaris.anticheat.core.PlayerData;
import com.velaris.anticheat.core.Verdict;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.logging.Level;
import org.bukkit.Bukkit;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

/** Trung tâm: cấu hình, dữ liệu người chơi, xử lý flag (cảnh báo / Discord / lệnh xử phạt). Chỉ dùng trên luồng chính. */
final class Engine {
    private final JavaPlugin plugin;
    private final Map<UUID, PlayerData> data = new HashMap<>();
    private final Set<UUID> alertsOff = new HashSet<>();
    final Map<Check, CheckSettings> checks = new EnumMap<>(Check.class);

    YamlConfiguration general;
    YamlConfiguration messages;
    YamlConfiguration discordCfg;
    Alerts alerts;
    DiscordNotifier discord;

    boolean consoleAlerts = true;
    boolean cancelFlaggedHits = false;
    long alertCooldownNanos = 1_500_000_000L;
    long discordCooldownNanos = 8_000_000_000L;
    double discordMinVl = 1.0;
    double minTps = 15.0;

    private long tick;
    private long lastErrorLogNanos;

    Engine(JavaPlugin plugin) { this.plugin = plugin; }

    long tick() { return tick; }
    void advance() { tick++; }

    // ------------------------------------------------------------------ dữ liệu người chơi

    PlayerData data(Player p) {
        return data.computeIfAbsent(p.getUniqueId(), PlayerData::new);
    }

    PlayerData peek(UUID id) { return data.get(id); }

    void remove(UUID id) {
        data.remove(id);
        alertsOff.remove(id);
    }

    boolean toggleAlerts(UUID id) {
        if (!alertsOff.add(id)) { alertsOff.remove(id); return true; }
        return false;
    }

    boolean alertsEnabledFor(UUID id) { return !alertsOff.contains(id); }

    /** Quyền bypass được cache 5 giây. */
    boolean bypass(Player p, PlayerData d) {
        if (d.bypassCheckedTick == Long.MIN_VALUE || tick - d.bypassCheckedTick >= 100) {
            d.bypass = p.hasPermission("velaris.bypass");
            d.bypassCheckedTick = tick;
        }
        return d.bypass;
    }

    CheckSettings s(Check c) { return checks.get(c); }

    // ------------------------------------------------------------------ cấu hình

    /** Nạp (hoặc nạp lại) toàn bộ cấu hình. Mọi lỗi đều được báo rõ trong console và dùng mặc định. */
    void load() {
        File dir = plugin.getDataFolder();
        File checkDir = new File(dir, "checks");
        if (!checkDir.exists() && !checkDir.mkdirs()) plugin.getLogger().warning("Không tạo được thư mục checks/");

        general = yaml("config.yml");
        messages = yaml("messages.yml");
        discordCfg = yaml("discord.yml");

        consoleAlerts = general.getBoolean("alerts.console", true);
        cancelFlaggedHits = general.getBoolean("cancel-flagged-hits", false);
        alertCooldownNanos = ms(general.getLong("alerts.cooldown-ms", 1500), 0, 60_000);
        minTps = Math.max(0.0, Math.min(20.0, general.getDouble("min-tps", 15.0)));
        discordCooldownNanos = ms(discordCfg.getLong("cooldown-seconds", 8) * 1000L, 0, 3_600_000);
        discordMinVl = Math.max(0.0, discordCfg.getDouble("min-vl", 1.0));

        // mỗi nhóm check một file riêng; thiếu file thì sinh file mặc định có chú thích
        checks.clear();
        for (String file : DefaultFiles.files()) {
            File f = new File(checkDir, file);
            if (!f.exists()) {
                try {
                    Files.writeString(f.toPath(), DefaultFiles.render(file), StandardCharsets.UTF_8);
                } catch (IOException e) {
                    plugin.getLogger().warning("Không ghi được checks/" + file + ": " + e.getMessage());
                }
            }
            YamlConfiguration y = new YamlConfiguration();
            try {
                y.load(f);
            } catch (Exception e) {
                plugin.getLogger().warning("checks/" + file + " lỗi cú pháp YAML (" + e.getMessage() + "), dùng mặc định cho file này.");
            }
            for (Check c : Check.values()) {
                if (!c.file().equals(file)) continue;
                String prefix = c.section() == null ? "" : c.section() + ".";
                checks.put(c, CheckSettings.load(y::get, prefix, c, w -> plugin.getLogger().warning("checks/" + file + ": " + w)));
            }
        }

        alerts = new Alerts(this, messages);
        if (discord != null) discord.close();
        discord = DiscordNotifier.create(plugin, discordCfg, this);
    }

    private YamlConfiguration yaml(String name) {
        File f = new File(plugin.getDataFolder(), name);
        if (!f.exists()) plugin.saveResource(name, false);
        YamlConfiguration y = new YamlConfiguration();
        try {
            y.load(f);
        } catch (Exception e) {
            plugin.getLogger().warning(name + " lỗi cú pháp YAML (" + e.getMessage() + "), dùng giá trị mặc định trong plugin.");
        }
        try (var in = plugin.getResource(name)) {
            if (in != null) y.setDefaults(YamlConfiguration.loadConfiguration(new InputStreamReader(in, StandardCharsets.UTF_8)));
        } catch (IOException ignored) {
            // không có mặc định nhúng: bỏ qua
        }
        return y;
    }

    private static long ms(long v, long lo, long hi) { return Math.max(lo, Math.min(hi, v)) * 1_000_000L; }

    void close() {
        if (discord != null) discord.close();
    }

    // ------------------------------------------------------------------ xử lý flag

    void handle(Player p, PlayerData d, Verdict v) {
        if (!v.flagged()) return;
        Check check = v.check();
        CheckSettings cs = checks.get(check);
        if (cs == null || !cs.enabled) return;
        if (lowTps()) return; // server đang lag: gói tin dồn cục, không đáng tin

        double total = d.addVl(check, v.weight(), tick);
        long now = System.nanoTime();
        int i = check.ordinal();

        if (cs.alert && (d.lastAlertNanos[i] == 0L || now - d.lastAlertNanos[i] >= alertCooldownNanos)) {
            d.lastAlertNanos[i] = now;
            alerts.send(p, check, cs, total, v.detail());
        }
        if (cs.discord && discord != null && total >= discordMinVl
                && (d.lastDiscordNanos[i] == 0L || now - d.lastDiscordNanos[i] >= discordCooldownNanos)) {
            d.lastDiscordNanos[i] = now;
            discord.flag(p, check, total, v.detail());
        }
        if (cs.punishVl > 0 && total >= cs.punishVl) punish(p, d, check, cs, total);
    }

    private void punish(Player p, PlayerData d, Check check, CheckSettings cs, double total) {
        d.resetVl(check);
        plugin.getLogger().info("Xử phạt " + p.getName() + " (" + check.display() + ", VL " + String.format("%.1f", total) + ")");
        if (discord != null) discord.punish(p, check, total, cs.commands);
        for (String raw : cs.commands) {
            String cmd = raw.replace("%player%", p.getName()).replace("%check%", check.display()).trim();
            if (cmd.startsWith("/")) cmd = cmd.substring(1);
            if (cmd.isEmpty()) continue;
            try {
                Bukkit.dispatchCommand(Bukkit.getConsoleSender(), cmd);
            } catch (Throwable t) {
                error("lệnh xử phạt '" + cmd + "'", t);
            }
        }
    }

    double tps() {
        try {
            double[] t = Bukkit.getTPS();
            return t.length == 0 ? 20.0 : Math.min(20.0, t[0]);
        } catch (Throwable t) {
            return 20.0;
        }
    }

    private boolean lowTps() { return minTps > 0.0 && tps() < minTps; }

    /** Ghi lỗi nội bộ nhưng không sập server và không spam log. */
    void error(String where, Throwable t) {
        long now = System.nanoTime();
        if (now - lastErrorLogNanos > 10_000_000_000L) {
            lastErrorLogNanos = now;
            plugin.getLogger().log(Level.WARNING, "Lỗi nội bộ tại " + where + " (đã bỏ qua, server vẫn chạy bình thường)", t);
        }
    }

    JavaPlugin plugin() { return plugin; }

    List<Player> staff() {
        java.util.ArrayList<Player> out = new java.util.ArrayList<>();
        for (Player p : Bukkit.getOnlinePlayers()) if (p.hasPermission("velaris.alerts") && alertsEnabledFor(p.getUniqueId())) out.add(p);
        return out;
    }
}
