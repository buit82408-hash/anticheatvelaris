package com.velaris.anticheat.core;

/** Trạng thái một thực thể tại một tick (dùng để "tua lại" bù độ trễ). */
public record Snapshot(long tick, double x, double y, double z, float yaw, float pitch,
                       double eyeH, double w, double h) {
    public Aabb box() { return Aabb.ofFeet(x, y, z, w, h); }
    public double eyeY() { return y + eyeH; }
    public double[] look() { return Look.dir(yaw, pitch); }
}
