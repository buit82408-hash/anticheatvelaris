package com.velaris.anticheat.core;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Các check chiến đấu (thuần toán học, không phụ thuộc Bukkit).
 *
 * Bù lag: máy khách của người đánh nhìn thấy mục tiêu ở vị trí cũ (ping/2 + nội suy). Vì vậy khoảng cách/tia
 * được đo trên nhiều vị trí lịch sử của mục tiêu trong "cửa sổ độ trễ" và lấy kết quả có lợi nhất cho người chơi.
 * Vị trí của chính người đánh không cần tua vì gói tin đến theo thứ tự.
 */
public final class CombatChecks {
    private CombatChecks() {}

    // ------------------------------------------------------------------ tiện ích

    public static int lagTicks(int pingMs, int capMs) {
        int p = Math.max(0, Math.min(pingMs, capMs));
        return Math.min(10, (int) Math.round(p / 50.0));
    }

    /** Các hộp của mục tiêu mà máy khách người đánh có thể đã thấy: hiện tại + cửa sổ [lag-1, lag+3] tick trước. */
    public static List<Aabb> rewind(Aabb now, History victim, long tick, int lag) {
        List<Aabb> out = new ArrayList<>(6);
        out.add(now);
        if (victim == null) return out;
        for (int m = Math.max(1, lag - 1); m <= lag + 3 && m < 60; m++) {
            Snapshot s = victim.at(tick - m);
            if (s != null) out.add(s.box());
        }
        return out;
    }

    // ------------------------------------------------------------------ Reach

    public static Verdict reach(PlayerData d, CheckSettings s, double range, double ex, double ey, double ez,
                                List<Aabb> boxes, int pingMs) {
        if (!s.enabled) return Verdict.NONE;
        double min = Double.MAX_VALUE;
        for (Aabb b : boxes) min = Math.min(min, b.distanceTo(ex, ey, ez));
        final double dist = min;
        final double allowed = range + s.p("extra");
        boolean v = dist > allowed;
        double inc = 1.0 + Math.min(2.0, (dist - allowed) / 0.3);
        return Buffers.push(d, Check.REACH, s, v, inc, 0.5, s.p("buffer"),
                () -> String.format(Locale.ROOT, "tầm đánh %.2f > %.2f (ping %dms)", dist, allowed, pingMs));
    }

    // ------------------------------------------------------------------ Hitbox

    /**
     * @param rot1 góc xoay (độ) giữa tick trước và hiện tại; rot2: giữa 2 tick trước; âm = không rõ
     */
    public static Verdict hitbox(PlayerData d, CheckSettings s, double ex, double ey, double ez, double[] look,
                                 double rot1, double rot2, List<Aabb> boxes, double maxDist) {
        if (!s.enabled) return Verdict.NONE;
        double maxRot = s.p("max-rotation");
        if (rot1 < 0 || rot2 < 0 || rot1 > maxRot || rot2 > maxRot) return Verdict.NONE; // xoay nhanh: bỏ qua
        double e = s.p("expand");
        boolean hit = false;
        for (Aabb b : boxes) {
            if (b.inflate(e).rayHits(ex, ey, ez, look[0], look[1], look[2], maxDist)) { hit = true; break; }
        }
        return Buffers.push(d, Check.HITBOX, s, !hit, 1.0, 0.5, s.p("buffer"),
                () -> String.format(Locale.ROOT, "tia nhìn trượt hitbox (nới %.2f)", e));
    }

    // ------------------------------------------------------------------ KillAura: góc nhìn

    public static Verdict angle(PlayerData d, CheckSettings s, double ex, double ey, double ez, double[] look,
                                double[] prevLook, List<Aabb> boxes) {
        if (!s.enabled) return Verdict.NONE;
        double best = Double.MAX_VALUE;
        for (Aabb b : boxes) {
            best = Math.min(best, Look.aimError(look, ex, ey, ez, b));
            if (prevLook != null) best = Math.min(best, Look.aimError(prevLook, ex, ey, ez, b));
        }
        final double err = best;
        double max = s.p("max-angle");
        boolean v = err > max;
        double inc = 1.0 + Math.min(2.0, (err - max) / 45.0);
        return Buffers.push(d, Check.KILLAURA_ANGLE, s, v, inc, 0.5, s.p("buffer"),
                () -> String.format(Locale.ROOT, "lệch hướng nhìn %.0f°", err));
    }

    // ------------------------------------------------------------------ KillAura: đa mục tiêu

    /** (dx,dy,dz) là vector đơn vị từ mắt tới tâm nạn nhân. */
    public static Verdict multi(PlayerData d, CheckSettings s, int victimId, double dx, double dy, double dz, long nowNanos) {
        if (!s.enabled) return Verdict.NONE;
        Verdict out = Verdict.NONE;
        long window = (long) (s.p("window-ms") * 1_000_000.0);
        if (d.hasLastHit && victimId != d.lastHitId && nowNanos - d.lastHitNanos <= window) {
            double ang = Look.angleDeg(new double[] {d.lastDx, d.lastDy, d.lastDz}, new double[] {dx, dy, dz});
            final long ms = (nowNanos - d.lastHitNanos) / 1_000_000L;
            out = Buffers.push(d, Check.KILLAURA_MULTI, s, ang > s.p("min-angle"), 1.0, 0.25, s.p("buffer"),
                    () -> String.format(Locale.ROOT, "2 mục tiêu cách %.0f° trong %dms", ang, ms));
        } else {
            Buffers.push(d, Check.KILLAURA_MULTI, s, false, 1.0, 0.25, s.p("buffer"), () -> "");
        }
        d.hasLastHit = true;
        d.lastHitId = victimId;
        d.lastHitNanos = nowNanos;
        d.lastDx = dx;
        d.lastDy = dy;
        d.lastDz = dz;
        return out;
    }

    // ------------------------------------------------------------------ KillAura: xuyên khối

    /** @param blockDist khoảng cách từ mắt tới khối chắn đầu tiên trên tia, hoặc âm nếu không có */
    public static Verdict wall(PlayerData d, CheckSettings s, double blockDist, double dist) {
        if (!s.enabled || dist < s.p("min-distance")) return Verdict.NONE;
        boolean blocked = blockDist >= 0 && blockDist < dist - s.p("tolerance");
        return Buffers.push(d, Check.KILLAURA_WALL, s, blocked, 1.0, 0.5, s.p("buffer"),
                () -> String.format(Locale.ROOT, "đánh xuyên khối (khối ở %.2f, mục tiêu ở %.2f)", blockDist, dist));
    }

    // ------------------------------------------------------------------ KillAura: đánh khi đang dùng vật phẩm

    public static Verdict useItem(PlayerData d, CheckSettings s, boolean usingItem) {
        if (!s.enabled) return Verdict.NONE;
        return Buffers.push(d, Check.KILLAURA_ITEM, s, usingItem, 1.0, 0.5, s.p("buffer"),
                () -> "đánh khi đang giơ khiên/ăn/kéo cung");
    }

    // ------------------------------------------------------------------ KillAura: xoay ảo rồi quay lại (silent rotation)

    public static void snapStart(PlayerData d, CheckSettings s, long nowNanos, double[] prevLook, double[] look) {
        if (!s.enabled || prevLook == null) return;
        if (Look.angleDeg(prevLook, look) >= s.p("min-snap")) {
            d.snapPending = true;
            d.snapNanos = nowNanos;
            d.snapLook = prevLook;
        }
    }

    /** Gọi mỗi tick với hướng nhìn hiện tại của người chơi có snap đang chờ. */
    public static Verdict snapResolve(PlayerData d, CheckSettings s, long nowNanos, double[] look) {
        if (!d.snapPending) return Verdict.NONE;
        if (!s.enabled) { d.snapPending = false; return Verdict.NONE; }
        final double back = Look.angleDeg(d.snapLook, look);
        final long ms = (nowNanos - d.snapNanos) / 1_000_000L;
        if (back <= s.p("return-within")) {
            d.snapPending = false;
            return Buffers.push(d, Check.KILLAURA_SNAP, s, true, 1.0, 0.5, s.p("buffer"),
                    () -> String.format(Locale.ROOT, "xoay đột ngột rồi quay lại sau %dms (lệch %.0f°)", ms, back));
        }
        if (ms > s.p("window-ms")) {
            d.snapPending = false;
            return Buffers.push(d, Check.KILLAURA_SNAP, s, false, 1.0, 0.5, s.p("buffer"), () -> "");
        }
        return Verdict.NONE;
    }

    // ------------------------------------------------------------------ NoSwing

    /** Ghi nhận cú đánh. 1.9+: vung tay đến sau cú đánh; 1.8 (ViaVersion): đến trước. Chấp nhận cả hai. */
    public static void hit(PlayerData d, CheckSettings s, long nowNanos) {
        if (d.hasSwing && nowNanos - d.lastSwingNanos <= 150_000_000L) {
            Buffers.push(d, Check.NOSWING, s, false, 1.0, 0.5, s.p("buffer"), () -> "");
            d.hasPendingHit = false;
        } else {
            d.hasPendingHit = true;
            d.pendingHitNanos = nowNanos;
        }
    }

    public static void swing(PlayerData d, CheckSettings s, long nowNanos) {
        d.hasSwing = true;
        d.lastSwingNanos = nowNanos;
        if (d.hasPendingHit && nowNanos - d.pendingHitNanos <= 250_000_000L) {
            d.hasPendingHit = false;
            Buffers.push(d, Check.NOSWING, s, false, 1.0, 0.5, s.p("buffer"), () -> "");
        }
    }

    /** Gọi mỗi tick. */
    public static Verdict noSwingTick(PlayerData d, CheckSettings s, long nowNanos) {
        if (!d.hasPendingHit) return Verdict.NONE;
        if (!s.enabled) { d.hasPendingHit = false; return Verdict.NONE; }
        if (nowNanos - d.pendingHitNanos > (long) (s.p("wait-ms") * 1_000_000.0)) {
            d.hasPendingHit = false;
            return Buffers.push(d, Check.NOSWING, s, true, 1.0, 0.5, s.p("buffer"),
                    () -> "đánh mà không vung tay");
        }
        return Verdict.NONE;
    }

    // ------------------------------------------------------------------ TriggerBot

    /**
     * Số tick liên tiếp (tính ngược từ lúc đánh) mà tâm ngắm nằm trên mục tiêu.
     * Người thật cần ≥ ~4 tick phản xạ; trigger bot đánh ngay khi tâm ngắm vừa vào hitbox (run ≈ 1).
     */
    public static int onTargetRun(History attacker, Snapshot attackerNow, History victim, Aabb victimNow,
                                  long tick, int lag, double expand, int maxRun) {
        int run = 0;
        for (int k = 0; k < maxRun; k++) {
            Snapshot a = k == 0 ? attackerNow : attacker.at(tick - k);
            if (a == null) break;
            int m = k + lag;
            Aabb vb;
            if (m <= 0 || victim == null) {
                vb = victimNow;
            } else {
                Snapshot vs = victim.at(tick - m);
                if (vs == null) break;
                vb = vs.box();
            }
            double[] l = a.look();
            if (!vb.inflate(expand).rayHits(a.x(), a.eyeY(), a.z(), l[0], l[1], l[2], 12.0)) break;
            run++;
        }
        return run;
    }

    public static Verdict trigger(PlayerData d, CheckSettings s, long nowNanos, int run) {
        if (!s.enabled || run <= 0) return Verdict.NONE;
        double gapMs = d.hasSwing ? (nowNanos - d.lastSwingNanos) / 1e6 : 1e9;
        if (gapMs < s.p("min-gap-ms")) return Verdict.NONE; // đang spam click: không đủ điều kiện
        int n = (int) Math.min(32, Math.max(4, s.p("window")));
        if (d.trigIdx >= n) d.trigIdx = 0;
        boolean instant = run <= (int) s.p("instant-ticks");
        d.trig[d.trigIdx++] = instant;
        d.trigN = Math.min(n, d.trigN + 1);
        if (d.trigN >= n) {
            int inst = 0;
            for (int i = 0; i < n; i++) if (d.trig[i]) inst++;
            if (inst >= s.p("min-instant") && inst / (double) n >= s.p("ratio")) {
                d.trigN = 0;
                d.trigIdx = 0;
                final int fi = inst, fn = n;
                return Verdict.flag(Check.TRIGGERBOT, s.weight,
                        String.format(Locale.ROOT, "%d/%d cú đánh ngay khi tâm ngắm vừa vào hitbox", fi, fn));
            }
        }
        return Verdict.NONE;
    }
}
