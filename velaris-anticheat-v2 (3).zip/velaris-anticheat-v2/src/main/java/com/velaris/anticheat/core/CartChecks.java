package com.velaris.anticheat.core;

import java.util.Deque;
import java.util.Locale;

/**
 * AutoCart: đặt ray → đặt xe TNT → châm lửa quá nhanh, hoặc đặt/châm quá nhiều mỗi giây.
 * Chỉ theo dõi thao tác ĐẶT và CHÂM bằng bật lửa/lửa. Bắn xe bằng cung/tên lửa không bị tính, nên người chơi
 * bắn xe hoặc chơi bình thường không bị ảnh hưởng.
 */
public final class CartChecks {
    private CartChecks() {}

    public enum Event { RAIL, TNT, CART, IGNITE_CART, IGNITE_OTHER }

    /** @return {sequence, rate} */
    public static Verdict[] on(PlayerData d, Event e, long now, CheckSettings seq, CheckSettings rate) {
        Verdict vs = Verdict.NONE;
        Verdict vr = Verdict.NONE;
        switch (e) {
            case RAIL -> {
                d.hasRail = true;
                d.lastRailNanos = now;
                vr = rate(d, rate, d.railTimes, now, "rail-per-sec", "ray");
            }
            case TNT -> vr = rate(d, rate, d.tntTimes, now, "tnt-per-sec", "TNT");
            case CART -> {
                d.hasCart = true;
                d.lastCartNanos = now;
                vr = rate(d, rate, d.cartTimes, now, "cart-per-sec", "xe TNT");
            }
            case IGNITE_CART -> {
                vr = rate(d, rate, d.igniteTimes, now, "ignite-per-sec", "châm lửa");
                vs = sequence(d, seq, now);
            }
            case IGNITE_OTHER -> vr = rate(d, rate, d.igniteTimes, now, "ignite-per-sec", "châm lửa");
        }
        return new Verdict[] {vs, vr};
    }

    private static Verdict rate(PlayerData d, CheckSettings s, Deque<Long> q, long now, String key, String what) {
        if (!s.enabled) return Verdict.NONE;
        q.addLast(now);
        while (!q.isEmpty() && now - q.peekFirst() >= 1_000_000_000L) q.pollFirst();
        while (q.size() > 100) q.pollFirst();
        final int count = q.size();
        final double limit = s.p(key);
        return Buffers.push(d, Check.AUTOCART_RATE, s, count > limit, 1.0, 0.5, s.p("buffer"),
                () -> String.format(Locale.ROOT, "%s %d lần/giây (tối đa %.0f)", what, count, limit));
    }

    private static Verdict sequence(PlayerData d, CheckSettings s, long now) {
        if (!s.enabled || !d.hasCart) return Verdict.NONE;
        final long ci = now - d.lastCartNanos;
        if (ci < 0) return Verdict.NONE;
        if (ci > 2_000_000_000L) { // xe đặt đã lâu: thao tác bình thường
            return Buffers.push(d, Check.AUTOCART_SEQUENCE, s, false, 1.0, 1.0, s.p("buffer"), () -> "");
        }
        double a = s.p("rail-to-cart-ms") * 1e6;
        double b = s.p("cart-to-ignite-ms") * 1e6;
        double t = s.p("total-ms") * 1e6;
        boolean fastIgnite = ci <= b;
        long rc = d.lastCartNanos - d.lastRailNanos;
        boolean fastCart = d.hasRail && rc >= 0 && rc <= a;
        long total = now - d.lastRailNanos;
        boolean fastTotal = d.hasRail && total >= 0 && total <= t;
        double inc = 0.0;
        if (fastIgnite) inc = 1.0;
        if (fastIgnite && fastCart) inc = 2.0;
        if (fastTotal) inc = Math.max(inc, 2.0);
        final long fci = ci / 1_000_000L;
        final long frc = d.hasRail ? rc / 1_000_000L : -1;
        final long ftot = d.hasRail ? total / 1_000_000L : -1;
        return Buffers.push(d, Check.AUTOCART_SEQUENCE, s, inc > 0, inc, 1.0, s.p("buffer"),
                () -> String.format(Locale.ROOT, "chuỗi quá nhanh: ray→xe %dms, xe→châm %dms, tổng %dms", frc, fci, ftot));
    }
}
