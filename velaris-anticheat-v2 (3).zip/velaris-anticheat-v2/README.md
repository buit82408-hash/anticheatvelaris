# Velaris_Anticheat v2 — Combat (Paper 1.21.x, Java 21)

Xây lại từ đầu, chỉ tập trung combat, ưu tiên **bắt đúng – ít flag**.

## Các check

| File YAML | Check | Bắt gì |
|---|---|---|
| `reach.yml` | Reach | Đánh quá tầm (lấy tầm từ attribute, bù ping bằng lịch sử vị trí mục tiêu) |
| `hitbox.yml` | Hitbox | Tia nhìn không trúng hitbox mục tiêu (bỏ qua khi đang xoay nhanh) |
| `killaura.yml` | KillAura-Angle / Multi / Wall / Snap / UseItem, NoSwing | Lệch hướng nhìn; 2 mục tiêu khác hướng cùng lúc; đánh xuyên khối; xoay ảo rồi quay lại (silent rotation); đánh khi đang giơ khiên/ăn; đánh không vung tay |
| `triggerbot.yml` | TriggerBot | Liên tục đánh ngay tick đầu tiên tâm ngắm vừa vào hitbox (phản xạ không thể của người) |
| `autoclicker.yml` | AutoClicker-CPS / Pattern | CPS quá cao kéo dài; click đều như máy (độ lệch chuẩn khoảng cách tick) |
| `autocart.yml` | AutoCart-Sequence / Rate | Đặt ray → xe TNT → châm lửa quá nhanh; đặt ray/TNT/xe/châm quá nhiều mỗi giây |

**AutoCart chỉ tính thao tác ĐẶT và CHÂM bằng bật lửa/fire charge.** Bắn xe bằng cung/tên (kể cả bắn lửa) hoàn toàn không bị theo dõi, và một chuỗi nhanh đơn lẻ do lag không đủ để flag.

## Vì sao ít flag
- **Buffer**: mỗi check cộng điểm khi vi phạm, trừ điểm khi hợp lệ, chỉ flag khi vượt ngưỡng – một cú đánh lạ không bao giờ flag.
- **Bù ping**: vị trí mục tiêu được "tua lại" theo ping của người đánh (có jitter), lấy khoảng cách nhỏ nhất.
- **Dung sai**: Reach +0.12, Hitbox nới 0.12, bỏ qua Hitbox khi xoay >2°/tick.
- **Không flag khi server lag**: TPS < `min-tps` (mặc định 15) thì bỏ qua.
- VL tự giảm 1 điểm/phút.

## Cấu hình (mỗi thứ một file)
```
plugins/Velaris_Anticheat/
  config.yml       chung: cooldown cảnh báo, min-tps, cancel-flagged-hits
  messages.yml     nội dung cảnh báo (MiniMessage)
  discord.yml      webhook Discord
  checks/
    reach.yml  hitbox.yml  killaura.yml  triggerbot.yml  autoclicker.yml  autocart.yml
```
Trong mỗi file check: `enabled`, `alert`, `discord`, `vl-weight`, `punish.vl` + `punish.commands` (dùng `%player%`), và `settings` (ngưỡng, có chú thích từng dòng). Xem mẫu trong `config-preview/`. File thiếu/hỏng/giá trị sai → dùng mặc định và báo trong console, không làm sập plugin.

## Discord
1. Kênh Discord → Cài đặt kênh → Tích hợp → Webhook → Webhook mới → Sao chép URL.
2. `discord.yml`: `enabled: true`, dán `webhook-url`.
3. Trong game: `/velaris reload` rồi `/velaris webhook test`.

Embed có tên, check, VL, ping, thế giới, tọa độ, ảnh đầu, màu theo mức độ. Gửi bất đồng bộ, gom lô, tự xử lý rate-limit, không thể ping `@everyone`. Chỉ nhận URL `https://discord.com/api/webhooks/...`.

## Cảnh báo trong game
`VELARIS » Steve • Reach • VL 6.0 ▮▮▮▯▯▯▯▯▯▯ • 48ms` – màu xanh/vàng/đỏ theo VL. Rê chuột xem lý do, vị trí, TPS; bấm để dịch chuyển tới người chơi.

## Lệnh / quyền
`/velaris` (alias `/vac`): `status`, `alerts`, `checks`, `vl <tên>`, `reset <tên>`, `tp <tên>`, `webhook test`, `reload`.
Quyền: `velaris.admin` (lệnh), `velaris.alerts` (nhận cảnh báo), `velaris.bypass` (miễn kiểm tra).

## Build
```
mvn package        # ra target/Velaris_Anticheat.jar → bỏ vào plugins/
```
Kiểm thử logic (không cần server): 
```
javac -d out src/main/java/com/velaris/anticheat/core/*.java tools/CombatSim.java && java -cp out CombatSim
javac -d out2 -sourcepath src/main/java src/main/java/com/velaris/anticheat/core/*.java tools/ConfigWebhookTest.java && java -cp out2 com.velaris.anticheat.core.ConfigWebhookTest
```

## Khuyến nghị triển khai
1. Tuần đầu để `punish.vl: 0` (chỉ cảnh báo), theo dõi Discord, chỉnh ngưỡng.
2. Chỉ bật xử phạt tự động cho check bạn đã thấy ổn định (Reach, KillAura-Multi/Wall, TriggerBot, AutoCart-Sequence).

## Giới hạn cần biết
- Chưa build/chạy trên server Paper thật trong môi trường tạo ra nó (không có mạng để tải Paper API). Lõi kiểm tra đã được mô phỏng (62 kịch bản), cấu hình + webhook được test (31 kiểm tra); lớp nối Paper chỉ được kiểm tra biên dịch với API giả → cần chạy thử trên server test trước khi dùng thật.
- Plugin kỹ năng gây sát thương bằng API (không có vung tay) có thể làm NoSwing/Reach báo nhầm → tăng `buffer` hoặc tắt check đó.
- Hack nới hitbox/reach chỉ ≤0.12 block không thể phát hiện (đó là dung sai để tránh báo nhầm).
- Không có Velocity/AntiKB, Speed, Fly (ngoài phạm vi bản này).
